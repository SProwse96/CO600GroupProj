<?php
session_start();

if($_SESSION['email'] == "Admin@Admin.com"){
    // do nothing, theres no need to!
    include 'adminNavbar.php';


}
else if($_SESSION['email']){
    // do nothing, theres no need to!
    include 'LoggedInNavbars.php';
   
}
else{
    header('Location: Login.php'); //redirect back to login.php so users can access any info
    }

?>

<!DOCTYPE html>
<html lang="en">
    <head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">   
        
	<title>DomesticHelper</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
   
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->

<style>

body {
    text-align: center;
    background: url(https://wallpaperaccess.com/full/3898677.jpg);
    background-repeat: no-repeat;
    background-size: 1920px 1080px;
    }
    table, th, td {
    border: 1px solid black;
    
    }
    .tablecenter{
        margin-left: auto;
        margin-right: auto;
    }

    #customers {
font-family: Arial, Helvetica, sans-serif;
border-collapse: collapse;
width: 50%;
}

#customers td, #customers th {
border: 1px solid #ddd;
padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}
#customers tr:nth-child(ODD){background-color: #DDD;}

#customers tr:hover {background-color: #ddd;}

#customers th {
padding-top: 12px;
padding-bottom: 12px;
text-align: center;
background-color: #04AA6D;
color: white;
}


/* css button styles, credit to HTML Goodies - code found here : https://www.htmlgoodies.com/css/css-button-styles/ */


.viewButton {
display: inline-block;
background-color: #028DDE;
border-radius: 10px;
border: 3px double #cccccc;
color: white;
text-align: center;
font-size: 13px;
padding: 20px;
height: 20px;
width: 100px;
transition: all 0.5s;
cursor: pointer;
margin: 5px;
}
.viewButton input {
cursor: pointer;
display: inline-block;
position: relative;
transition: 0.5s;
}
.viewButton input:after {
content: '0bb';
position: absolute;
opacity: 0;
top: 0;
right: -20px;
transition: 0.5s;
}
.viewButton:hover {
background-color: #FFFFFF;
color: black;
}
.viewButton:hover input {
padding-right: 25px;

}
.viewButtonhover input:after {
opacity: 1;
right: 0;
}
.footertext{
    position: fixed;
}


    .checked { color: blue;}


</style>
</head>

                    <body>
                    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
                     integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
                     crossorigin="anonymous"></script>
                    
                

                                        

                    
                  
            <!-- display the email variable onbtained from the Login form email section and print out, page is only accessible if logged in. -->
                <h1>Services Homepage</h1>
                <br>
                <h3>Please selected services from the list below:</h3>
                <br>
                <table class="tablecenter" id="customers">
                    <thead>
                        <tr>
                            <div class="ting"></div></div>
                           
                            <th>Service Name</th>
                            <th>location</th>
                            <th>price per hour</th>
                            <th>rating <span class="fa fa-star checked"></span></th>
                            <th>View Service</th>
                    
                             
                            
                        </tr>
                    </thead>

                  
                        <?php
                        ?>


                        
                        <?php
                        $conn = new mysqli ("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");
                        
                        if($conn->connect_error){
                            die("Connection error: " . $conn->connection_error);
                        }
                        
                        
                        $query="SELECT ServiceID, servicename, location, rating, price FROM Service";    
                        $res=$conn->query($query);
                        
                        

                             while($row=$res->fetch_assoc()){

                                echo "<tr>";
                              
                                
                                
                                echo "<td>" . $row['servicename'] . " " . "</td>";
                              
                                echo "<td>" . $row['location'] . " " . "</td>";
                              
                                echo "<td>" . $row['rating'] . "" . "</td>"; // edit this one tope! try messing with other rating keywords incase this doesnt work
                                echo "<td>" . "£" . $row['price'] . " " . "</td>";
                                
                                echo "<td><form action=viewService.php method=post>
                                 <input name=servicename type=hidden value='".$row['servicename']."'>
                                 <input name=location type=hidden value='".$row['location']."'>
                                 <input name=price type=hidden value='".$row['price']."'>
                                 <input name=rating type=hidden value='".$row['rating']."'>
                                 <input name=ServiceID type=hidden value='".$row['ServiceID']."'>
                                
                                 
                                 

                                 <input type=submit name=viewButton class=viewButton value=Book></form></td>";
                                echo "</tr>";
                              
                                }
                            $conn->close();
                             ?>
                             
                                   
                    </table>
                            

                    <script>
	function myFunction() {
  	var x = document.getElementById("myTopnav");
  	if (x.className === "topnav") {
    x.className += " responsive";
  	} else {
    x.className = "topnav";
  	}
	}
</script>

<div>
<p class="footertext" style="color:white" id="bottomnav">Website created by Sam, Tope, Saahil & Esther</p>

</div>                  
</body>   
    </html>
    

