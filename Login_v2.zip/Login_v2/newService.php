<?php
//start the session
session_start();
//load the database connection, employee navbar for navigation and current session details
require_once('setup.php');
include 'employeeNavbar.php';
include 'sessionTime.php';
//database query
$conn = mysqli_connect("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20") or die("something went wrong, please try again!");


//if the session is set and a variable called EmpID is set, do nothing and stay on this page, otherwise, redirect back to services.php
if (isset($_SESSION)) {
	if (isset($_SESSION['EmpID'])) {
		//do nothing, carry on as usual.
	} else {
		echo '<script type="text/javascript">';
		echo 'window.location.href="Services.php";';
		echo '</script>';
	}
}
//any current session variables related to a serivce are set, remove them.
if (isset($_SESSION['servicename'])) {
	unset($_SESSION['servicename'], $_SESSION['servicedesc'], $_SESSION['location'], $_SESSION['rating'], $_SESSION['price'], $_SESSION['employeename']);
}


?>

<?php
//once the form for a newservice is set, insert all the details of this new service (alongside the employee creating the service) into the database via a prepared statement.
if (isset($_POST['submit'])) {

	$servicename = $_POST['servicename'];
	$location = $_POST['location'];
	$price = $_POST['price'];
	$servicedesc = $_POST['servicedesc'];
	$EmpID = $_SESSION['EmpID'];
	$employeename = $_SESSION['fname'] . ' ' . $_SESSION['sname']; //bind the first and surname of the employee logged in into 1 varable.

	//if any of the input fields aren't null, insert into the database
	if ($servicename != null && $location != null && $price != null & $servicedesc != null) {


		$stmt = $conn->prepare("INSERT INTO Service (employeename,location,servicename,servicedesc,price,EmpID) VALUES (?,?,?,?,?,?)");
		$stmt->bind_param("ssssii", $employeename, $location, $servicename, $servicedesc, $price, $EmpID);
		$stmt->execute();
		$stmt->close();
?>
		<script>
			Swal.fire({
				icon: 'success',
				title: 'new service added',
				showConfirmButton: false,
				timer: 5000
			}).then(function() {
				window.location = "https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/Profileemp.php";
			});
		</script>


	<?php
	}
	//otherwise throw error.
	else {

	?>
		<script>
			Swal.fire({
				icon: 'error',
				title: 'Error has occured, please try again later.',
				showConfirmButton: false,
				timer: 2000
			})
		</script>


<?php
	}
}



?>

<!DOCTYPE html>
<html lang="en">

<head>

	<style>
		#logincontainer {
			padding-bottom: 100px;
		}

		#bottomnav {
			background-color: #333;
			overflow: hidden;

			bottom: 0;
			width: 100%;
		}
	</style>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>DomesticHelper</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- importing of stylesheets such as fontawesome, bootstrap. -->
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico" />
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<!--===============================================================================================-->
</head>

<body>

	<div class="limiter">
		<div class="container-login100" id="logincontainer">
			<div class="wrap-login100">

				<!-- form for which employee has to enter all the details of their new service -->
				<form class="login100-form validate-form" method="post">
					<span class="login100-form-title p-b-26">
						New Service
					</span>
					<span class="login100-form-title p-b-48">
						<img src="../logo/DomesticLogo2.png" style="height: 200px; width: 250px">
					</span>

					<div class="wrap-input100 validate-input">
						<p>Service name</p>
						<input class="input100" name="servicename" type="servicename" id="servicename" maxlength="50" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<p>Service description</p>
						<input class="input100" name="servicedesc" type="servicedesc" id="servicedesc" required maxlength="150">
						<span class="focus-input100"></span>
					</div>


					<p>Location to offer service</p>
					<!-- dropdown menu of select locations where the employee would like to offer their service -->
					<span class="focus-input100"></span>
					<select value="" required name="location" type="location" id="location">
						<option value="">Select</option>
						<option value="Ashford" name="location" type="location" id="location">Ashford</option>
						<option value="Canterbury" name="location" type="location" id="location">Canterbury</option>
						<option value="Faversham" name="location" type="location" id="location">Faversham</option>
						<option value="Maidstone" name="location" type="location" id="location">Maidstone</option>
						<option value="Margate" name="location" type="location" id="location">Margate</option>
						<option value="Medway" name="location" type="location" id="location">Medway</option>
						<option value="Whitstable" name="location" type="location" id="location">Whitestable</option>
						<option value="Wye" name="location" type="location" id="location">Wye</option>

					</select>
					<br>
					<br>
					<div class="wrap-input100 validate-input">
						<p>Price per hour (excluding £ sign)</p> <!-- has to exclude currency symbol as it wont enter into the database otherwise -->
						<input class="input100" name="price" type="price" id="price" required>
						<span class="focus-input100"></span>
					</div>

					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<!-- button to submit the service details, will then go through the isset php function above starting on line 32, then redirect back to profile page of employee. -->
						
							<button class="login100-form-btn" type="submit" name="submit" href="profileemp.php">
								Submit
							</button>
						</div>
					</div>

					<div class="text-center p-t-115">
						<a class="txt2" href="Profileemp.php">
							Go back
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>

	<!-- declare our AJAX function, once register button is clicked, confirm entered detials match database -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<script type="text/javascript">


	</script>


</body>
<div>
	<!-- footer navbar displaying group members -->
	<p class="footertext" style="color:white" id="bottomnav">Website created by Sam, Tope, Saahil</p>

</div>

</html>