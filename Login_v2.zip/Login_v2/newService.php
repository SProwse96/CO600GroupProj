<?php
session_start();
require_once('setup.php');
include 'adminNavbar.php'; 

if($_SESSION['email'] != "Admin@Admin.com"){
    // do nothing, theres no need to!
    header('Location: Login.php');
    
}


if (isset($_POST['submit'])){
	
	$conn = new mysqli ("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");

	$servicename = $conn->real_escape_string($_POST['servicename']);
	$location = $conn->real_escape_string($_POST['location']);
	$rating = $conn->real_escape_string($_POST['rating']);
	$price = $conn->real_escape_string($_POST['price']);
	



	
	if($price > 0){
		
		$conn ->query("INSERT INTO Service (servicename,location,rating,price) VALUES ('$servicename', '$location', '$rating', '$price')");
		/* $conn ->query("INSERT INTO employee (EmpID, fname, sname) VALUES ('$servicename', '$location', '$rating', '$price')"); */
		echo("<script>alert('Service added.')</script>");
 		echo("<script>window.location = 'Services.php';</script>");	
	}
	else{
		echo("<script>alert('Wrong Gender, registration failed.')</script>");
}

	
	
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>DomesticHelper</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>

<body>

<script>

	//function to show password or not on register page.


</script>

<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form" method="post">
					<span class="login100-form-title p-b-26">
						New Service
					</span>
					<span class="login100-form-title p-b-48">
					<img src="../logo/DomesticLogo2.png" style="height: 200px; width: 250px">
					</span>

                    <div class="wrap-input100 validate-input">
						<p>Service name</p>
						<input class="input100" name="servicename" type="servicename" id="servicename" required>
						<span class="focus-input100"></span>
					</div>

                    <div class="wrap-input100 validate-input">
					<p>Location</p>
						<input class="input100" name="location" type="location" id="location" required>
						<span class="focus-input100"></span>
					</div>

                    <div class="wrap-input100 validate-input">
					<p>Rating</p>
						<input class="input100" name="rating" type="rating" id="rating" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input">
					<p>Price</p>
						<input class="input100" name="price" type="price" id="price" required>
						<span class="focus-input100"></span>
					</div>

                    

					

					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" type="submit" name="submit" href="login.php" >
								Submit
							</button>
						</div>
					</div>

					<div class="text-center p-t-115">
						<a class="txt2" href="login.php">
							Go back
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>

    <!-- declare our AJAX function, once register button is clicked, confirm entered detials match database -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<script type="text/javascript">
	
	
</script>


</body>
</html>