<?php
session_start();
 
 
if($_SESSION['email'] == "Admin@Admin.com"){
    // do nothing, theres no need to!
    include 'adminNavbar.php';
    
}
else if($_SESSION['email']){
    // do nothing, theres no need to!
    include 'LoggedInNavbars.php';

}
else{
    header('Location: Login.php'); //redirect back to login.php so users can access any info
    }


	if (isset($_POST['submit'])){
		
		$servicename = $_POST['servicename'];
		$location = $_POST['location'];
		$rating = $_POST['rating'];
		$price = $_POST['price'];
		$time = $_POST['time'].":00";
		$date = $_POST['date'];
		$serviceID = $_POST['ServiceID'];
		
		$userID = $_SESSION['id'];
		
		

		$conn = new mysqli ("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");

		$sql = $conn->query("SELECT Time, Date FROM Bookings WHERE Time = '$time' AND Date = '$date'");
		if($sql->num_rows > 0){
			echo("<script>alert('Booking slot already made, please choose different date or time')</script>");
		}
		

		else{
			
		
			
		// original query, which will be used: $conn -> query("INSERT INTO Bookings (servicename, Time, Date, id) VALUES ('$servicename', '$time', '$date', '$userID')");
		$conn -> query("INSERT INTO Bookings (servicename, Time, Date, id, ServiceID) VALUES ('$servicename', '$time', '$date', '$userID','$serviceID')");
		
		
		echo '<script type="text/javascript">'; 
		echo 'alert("Booking Successfully Added");'; 
		echo 'window.location.href = "Profile.php";';
		echo '</script>';
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>DomesticHelper</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->

<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">

</head>
<style>
.wrap-login100 {
    width: 600px;
    height: 750px;
}

.wrap-input100{
    width: 25%;
}

.login100-form-btn {
   
    
}
.center {
    width: 25%;
  text-align: center;
  
  margin-left: 80%;
}

.dateTime {
	width: 175%;
}
.timepicker{
	border: 1px solid;
}
.txt2{
	bottom: 0;
	right: 0;
}






</style>
<script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
<body>

<script>

//credit for timepicker code - timepicker.co - source code here: https://timepicker.co/

(function($) {
    $(function() {
        $('input.timepicker').timepicker({
			timeFormat: 'HH:mm',
    interval: 60,
    minTime: '8',
    maxTime: '8:00pm',
    defaultTime: '10',
    startTime: '10:00',
    dynamic: false,
    dropdown: true,
    scrollbar: true,
	
		});
		
    });
})(jQuery);

</script>

<script>
function myFunction() {
	
	window.location.replace("http://pornhub.com");
    
}

</script>


<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form p-b 20" method="post">
					<span class="login100-form-title">
						Viewing Service
					</span>
					
					<p>Service Name</p>
                    <div class="wrap-input100 validate-input">
						<input class="input100" name="servicename" type="servicename" id="servicename" value="<?php print_r($_POST['servicename']); ?>" required readonly="readonly">
						<span class="focus-input100"></span>
					</div>
					<p>Service Location</p>
                    <div class="wrap-input100 validate-input">
						<input class="input100" name="location" type="location" id="location" value="<?php print_r($_POST['location']); ?>" required readonly="readonly">
						<span class="focus-input100"></span>
					</div>
					<p>Service Rating</p>
                    <div class="wrap-input100 validate-input">
						<input class="input100" name="rating" type="rating" id="rating" value="<?php print_r($_POST['rating']); ?>" required readonly="readonly">
						<span class="focus-input100"></span>
					</div>
					<p>Service Price</p>
					<div class="wrap-input100 validate-input">
						<input class="input100" name="price" type="price" id="price" value="<?php print_r($_POST['price']); ?>"  readonly="readonly">
						<span class="focus-input100"></span>
					</div>


					<!-- pass the id through for the service but make it invisible on the viewService screen -->
					<input class="input100" name="ServiceID" type="hidden" id="ServiceID" value="<?php print_r($_POST['ServiceID']); ?>"  readonly="readonly">
						<span class="focus-input100"></span>
					
					
					<div>
						<p>Date</p>
					<input type="date" id="date" name="date" required>
					</div>
					<div>
						<p>Time</p>
						<input class="timepicker" name="time" id="time" maxlength="0"> <!-- Stop users inputting custom times -->
					</div>
					

                    

					
					
					<div class="center">
					
						<div class="wrap-login100-form-btn">
						
							<div class="login100-form-bgbtn"></div>
							
							<button class="login100-form-btn" type="submit" name="submit" href="Login.php" onclick="myFunction()">
								Make a booking
							</button>
							
						</div>
						
						<a class="txt2 p-b 20" href="Services.php">
							Go back
						</a>
					</div>

					
						
					
				</form>
			</div>
		</div>
	</div>




    <!-- declare our AJAX function, once register button is clicked, confirm entered detials match database -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<script type="text/javascript">
	
	
</script>


</body>
</html>