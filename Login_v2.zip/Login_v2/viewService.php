<?php
session_start();

if ($_SESSION['email'] == "Admin@Admin.com") {
	// do nothing, theres no need to!
	include 'adminNavbar.php';
} else if ($_SESSION['email']) {
	// do nothing, theres no need to!
	include 'LoggedInNavbars.php';
} else {
	header('Location: Login.php'); //redirect back to login.php so users can access any info
}
//set all the variables of the service within $_SESSION, this is to prevent the variables from returning undefined when a new request is sent to the browser( CTRL + F5).
if (!isset($_SESSION['servicename'])) {
	$_SESSION['servicename'] = $_POST['servicename'];
	$_SESSION['servicedesc'] = $_POST['servicedesc'];
	$_SESSION['location'] = $_POST['location'];
	$_SESSION['rating'] = $_POST['rating'];
	$_SESSION['price'] = $_POST['price'];
	$_SESSION['employeename'] = $_POST['employeename'];
	$_SESSION['serviceID'] = $_POST['ServiceID'];
}
//var_dump($_SESSION); show details of session
if (isset($_POST['submit'])) {

	$conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");

	$servicename = $_POST['servicename'];
	$servicedesc = $_POST['servicedesc'];
	$location = $_POST['location'];
	$rating = $_POST['rating'];
	$price = $_POST['price'];
	$time = $_POST['time'];
	$endtime = $_POST['endtime'];
	$date = $_POST['date'];
	$serviceID = $_POST['ServiceID'];
	$EmpID = $_POST['EmpID'];
	$userID = $_SESSION['id'];
	$currentdate = date("Y-m-d"); //get current date in same format as database.
	$currenttime = date("H:i:s"); //get current time in 24h format (same as the time and endtime selections on this webpage).


	//if the date selected by the user is less than the current date, throw error and dont submit form, else, move on to checking the time.
	if ($date < $currentdate) {
		echo '<script type="text/javascript">';
		echo 'alert("date is in the past, please amend.");';
		echo '</script>';
		// if the date is the same as the current date and the time is less than real time, throw error, if not, continoue.
	} else if (($date == $currentdate) && ($time < $currenttime)) {
		echo '<script type="text/javascript">';
		echo 'alert("time or endtime is in the past, please amend.");';
		echo '</script>';
	} else {

		// -- $sql2 stops bookings being prevented that are inside the timeslots of other bookings.('$time' >= Time AND '$endtime' <= endtime) 
		// -- $sql3 stops endtime overlapping with another booking -- ('$time' <= Time AND '$endtime' >= Time)
		// -- $sql4 stops time overlaps with another booking -- ('$time' >= Time AND '$time' <= endtime)
		$sql2 = $conn->query("SELECT ServiceID, Time, endtime, Date FROM Bookings WHERE Date = '$date' AND ServiceID = '$serviceID' AND ('$time' >= Time AND '$endtime' <= endtime)");
		$sql3 = $conn->query("SELECT ServiceID, Time, endtime, Date FROM Bookings WHERE Date = '$date' AND ServiceID = '$serviceID' AND ('$time' >= Time AND '$time' <= endtime)");
		$sql4 = $conn->query("SELECT ServiceID, Time, endtime, Date FROM Bookings WHERE Date = '$date' AND ServiceID = '$serviceID' AND ('$time' <= Time AND '$endtime' >= Time)");




		if ($sql2->num_rows > 0) {
			echo ("<script>alert('Your booking start time and endtime interfere with another booking, please change both of these values.')</script>");
		} else if ($sql3->num_rows > 0) {
			echo ("<script>alert('Your start time interferes with another booking, please make this earlier!.')</script>");
		} else if ($sql4->num_rows > 0) {
			echo ("<script>alert('Your end time interferes with another booking, please make this earlier. If your booking is for one hour only, please also adjust your start time.')</script>");
		} else if ($endtime < $time) {
			echo '<script type="text/javascript">';
			echo 'alert("endtime is before start time, please amend");';
			echo '</script>';
		} elseif ($endtime == $time) {
			echo '<script type="text/javascript">';
			echo 'alert("start time and end time are the same, please amend.");';
			echo '</script>';
		} else {


			$conn->query("INSERT INTO Bookings (servicename, servicedesc, location, Date, Time, endtime, id, ServiceID, EmpID, acceptedBy) VALUES ('$servicename', '$servicedesc', '$location', '$date', '$time', '$endtime', '$userID','$serviceID', '$EmpID', 'Awaiting Confirmation')");

			echo '<script type="text/javascript">';
			echo 'alert("Booking requested");';
			echo 'window.location.href = "Profile.php";';
			echo '</script>';
		}
	}
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>DomesticHelper</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico" />
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<!--===============================================================================================-->

	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">

</head>
<style>
	.wrap-login100 {
		width: 6000px;
		height: 1300px;
		margin-bottom: 125px;
	}

	.wrap-input100 {
		width: 25%;
	}

	.center {
		width: 25%;
		text-align: center;

		margin-left: 80%;
	}

	.dateTime {
		width: 175%;
	}

	.timepicker {
		border: 1px solid;
	}

	.timepicker2 {
		border: 1px solid;
	}

	.txt2 {
		bottom: 0;
		right: 0;
	}

	/*.full-width {
		width: 100%;
	} */
</style>
<script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>

<body>

	<script>
		//credit for timepicker code - timepicker.co - source code here: https://timepicker.co/

		(function($) {
			$(function() {
				$('input.timepicker').timepicker({
					timeFormat: 'HH:mm',
					interval: 60,
					minTime: '8',
					maxTime: '8:00pm',
					defaultTime: '10',
					startTime: '10:00',
					dynamic: false,
					dropdown: true,
					scrollbar: true,

				});

			});
		})(jQuery);
	</script>
	<script>
		//credit for timepicker code - timepicker.co - source code here: https://timepicker.co/

		(function($) {
			$(function() {
				$('input.timepicker2').timepicker({
					timeFormat: 'HH:mm',
					interval: 60,
					minTime: '8',
					maxTime: '8:00pm',
					defaultTime: '11',
					startTime: '11:00',
					dynamic: false,
					dropdown: true,
					scrollbar: true,

				});

			});
		})(jQuery);
	</script>

	<script>
		function myFunction() {

			window.location.replace("https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/Profile.php");

		}
	</script>
	<style>
		table,
		td,
		th {
			border: 1px solid black;
		}

		table {
			border-collapse: collapse;
			width: 100%;
			margin-left:10px;
		}

		td {
			height: 20px;
			vertical-align: bottom;
			width: 50%;
		}
		 .testWidth{
			width: 25%;
		}
		th{
			width: 25%;
		}
	
		#serviceDetails{
			width: 30%;
			margin-right: auto;
			margin-left: 200px;
		}
		#reviewDetails{
			width: 30%;
			margin-left: auto;
			margin-right: 200px;
		}
	</style>

	<div class="limiter">

	
		<div class="container-login100">
		
						
			<div class="wrap-login100" id="serviceDetails">
				<!-- this returns the data you want if you put it inside the form, but we need it outside the form so it does not interfere with the date -->
			


				<form class="login100-form validate-form p-b 20" method="post" id="form1">
					
						<span class="login100-form-title">
							Viewing Service<br>

						</span>


						<p>Service Name</p>
						<div class="wrap-input100 validate-input full-width">
							<input class="input100" name="servicename" type="servicename" id="servicename" value="<?php print_r($_SESSION['servicename']); ?>" required readonly="readonly">
							<span class="focus-input100"></span>
						</div>


						<p>Service Description</p>
						<div class="wrap-input100 validate-input full-width">
							<input class="input100" name="servicedesc" type="servicedesc" id="servicedesc" value="<?php print_r($_SESSION['servicedesc']); ?>" required readonly="readonly">
							<span class="focus-input100"></span>
						</div>


						<p>Service Location</p>
						<div class="wrap-input100 validate-input full-width">
							<input class="input100" name="location" type="location" id="location" value="<?php print_r($_SESSION['location']); ?>" required readonly="readonly">
							<span class="focus-input100"></span>
						</div>
						<p>Service Rating (out of 5)</p>
						<div class="wrap-input100 validate-input">
							<input class="input100" name="rating" type="rating" id="rating" value="<?php print_r($_SESSION['rating']) ?>" required readonly="readonly" maxlength="5">
							<span class="focus-input100"></span>
						</div>
						<p>Service Price (in £)</p>
						<div class="wrap-input100 validate-input">
							<input class="input100" name="price" type="price" id="price" value="<?php print_r($_SESSION['price']); ?>" readonly="readonly">
							<span class="focus-input100"></span>
						</div>

						<p>Offered By</p>
						<div class="wrap-input100 validate-input">
							<input class="input100" name="employeename" type="employeename" id="employeename" value="<?php print_r($_SESSION['employeename']); ?>" readonly="readonly" maxlength="3">
							<span class="focus-input100"></span>
						</div>


						<!-- pass the id through for the service but make it invisible on the viewService screen -->
						<input class="input100" name="ServiceID" type="hidden" id="ServiceID" value="<?php print_r($_POST['ServiceID']); ?>" readonly="readonly">
						<input class="input100" name="EmpID" type="hidden" id="EmpID" value="<?php print_r($_POST['EmpID']); ?>" readonly="readonly">
						<span class="focus-input100"></span>


						<div>
							<p>Date</p>
							<input type="date" id="date" name="date" required>
						</div>
						<div>
							<p>Time</p>
							<input class="timepicker" name="time" id="time" maxlength="0"> <!-- Stop users inputting custom times -->
						</div>

						<div>
							<p>End Time</p>
							<input class="timepicker2" name="endtime" id="endtime" maxlength="0"> <!-- Stop users inputting custom times -->
						</div>

						<div class="center">

							<div class="wrap-login100-form-btn">

								<div class="login100-form-bgbtn"></div>

								<button class="login100-form-btn" type="submit" name="submit" href="Login.php" onclick="myFunction()">
									Make a booking
								</button>

							</div>

							<a class="txt2 p-b 20" href="Services.php">
								Go back
							</a>
						</div>
				</form>
			</div>
			<div class="wrap-login100" id="reviewDetails">
				<!-- this returns the data you want if you put it inside the form, but we need it outside the form so it does not interfere with the date -->
				<span class="login100-form-title">
							Recent Reviews<br>

						</span>
					<table>
						<tr class="testWidth2">
							<th>Review Description</th>
							<th>Rating</th>
							<th>Location</th>
							<th>Date</th>
						</tr>
						</table>
						<?php

						$conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");
						$userID = $_SESSION["id"];
						$serviceID = $_SESSION["serviceID"];
						$query = "SELECT reviewdescription, rating, location, date FROM reviews WHERE serviceID = '$serviceID' "; //$query says to fetch reviews that match the current service id, which is stored in the users session (check line 23)
						$res = $conn->query($query);
						while ($row = $res->fetch_assoc()) {
							$reviewdescription = $row['reviewdescription']; //print them out in a table, not working though, you will need to fix this!
							$rating = $row['rating'];
							$rating = $row['location'];
							$rating = $row['date'];
							echo "<table class=reviewsTable ><tr>";


							echo "<td class=testWidth>" . $row["reviewdescription"] . "</td><td class=testWidth>" . $row["rating"] . "</td><td class=testWidth>" . $row["location"] . "</td><td class=testWidth>" . $row["date"] . "</td></tr>";

							echo "</table>";
						}

						?>
						
						
			</div>
			
		</div>
	</div>

	<!-- declare our AJAX function, once register button is clicked, confirm entered detials match database -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
	<script type="text/javascript">


	</script>


</body>

</html>