<!-- Credit for responsive navbar: How to create a responsive top navigation bar by W3Schools, source is here : https://www.w3schools.com/howto/howto_js_topnav_responsive.asp -->
<!DOCTYPE html>
<html>

<head>

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <style>
    /* styling of the body element */
    body {
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
    }
    /* styling of the text in the navbar */
    .fontstyle {
      font-family: Arial, Helvetica, sans-serif;
      margin-top: 15px;
    }
    /*positioning of navbar at top and background colour change */
    .topnav {
      overflow: hidden;
      background-color: #333;
    }
     /* styling of the anchor tags within the navbar */
    .topnav a {
      float: left;
      display: block;
      color: #f2f2f2;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
      font-size: 17px;
    }
     /* change the colour of text and background colour of each anchor element when hovered over the in navbar */
    .topnav a.navBarOptions:hover {
      background-color: #ddd;
      color: black;
    }
    /* our minimised menu button, if the browser isnt minimised enough, dont display */
    .topnav .icon {
      display: none;
    }
     
    

    #bottomnav {
      background-color: #333;
      overflow: hidden;

      bottom: 0;
      width: 100%;
    }

    /* if the width of the screen becomes less than 600px, place all navbar elements within a collapsible menu */
    @media screen and (max-width: 600px) {
      .topnav a:not(:first-child) {
        display: none;
      }

      .topnav a.icon {
        float: right;
        display: block;
      }
    }
    /* otherwise return the navbar to normal */
    @media screen and (max-width: 600px) {
      .topnav.responsive {
        position: relative;
      }

      .topnav.responsive .icon {
        position: absolute;
        right: 0;
        top: 0;
      }

      .topnav.responsive a {
        float: none;
        display: block;
        text-align: left;
      }
    }
    /* align text in bottom navbar to the center */
    .footertext {
      text-align: center;
    }
  </style>
</head>

<body>
 <!-- Navbar menu at top with links to other pages -->
  <div class="topnav" id="myTopnav">
    <a><img src="../logo/DomesticLogo2.png" alt="Logo" style="height: 50px; width: 75px"> </a>
    <a href="About.php" class="fontstyle">About us</a>
    <a href="Guide.php" class="fontstyle">Guide</a>
    <a href="Logout.php" class="fontstyle">Logout</a>
    <a href="newService.php" class="fontstyle">New Service</a>
    <a href="Profileemp.php" class="fontstyle">Profile</a>
    <a href="javascript:void(0);" class="icon">
      <i class="fa fa-bars"></i>
    </a>
  </div>


  <!-- jquery and javascript scripts -->

  <div id="dropDownSelect1"></div>

  <!--===============================================================================================-->
  <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
  <!--===============================================================================================-->
  <script src="vendor/animsition/js/animsition.min.js"></script>
  <!--===============================================================================================-->
  <script src="vendor/bootstrap/js/popper.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <!--===============================================================================================-->
  <script src="vendor/select2/select2.min.js"></script>
  <!--===============================================================================================-->
  <script src="vendor/daterangepicker/moment.min.js"></script>
  <script src="vendor/daterangepicker/daterangepicker.js"></script>
  <!--===============================================================================================-->
  <script src="vendor/countdowntime/countdowntime.js"></script>
  <!--===============================================================================================-->
  <script src="js/main.js"></script>


</body>

</html>