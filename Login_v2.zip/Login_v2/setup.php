<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php 
echo "<link rel=icon href=../Logo/favicon.ico type=image/x-icon />";
$servername = "dragon.kent.ac.uk";
$database_username = "comp6000_20";
$database_password = "wrochs6";
$database_name = "comp6000_20";

$conn = new mysqli($servername, $database_username, $database_password, $database_name);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


?>