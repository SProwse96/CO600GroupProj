<?php 

$database_username = "comp6000_20";
$database_password = "wrochs6";
$database_name = "comp6000_20";

$database = new PDO('mysql:host=dragon.kent.ac.uk;dbname=' . $database_name . ';charset=utf8', $database_username, $database_password);
$database->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>