<?php
session_start();
require_once('setup.php');


$email 			= 	$_POST['email'];
$password 		= 	$_POST['password'];
$saltstring 	= 	"46dgsgresg342r2rrfds";
$password 		= 	$_POST['password'].$saltstring;
$password 		= 	sha1($password); 

$sql = "SELECT * FROM users WHERE email = ? AND password = ? LIMIT 1";
$statement  = $database->prepare($sql);
$result = $statement->execute([$email, $password]);


if($result){
	$user = $statement->fetch(PDO::FETCH_ASSOC);
	if($statement->rowCount() > 0){
		$_SESSION['Login_v2'] = $user;
		echo "Login succesful! redirecting...";
	}else{
		echo "No such user found"; 		
	}
}else{
	echo 'Cant reach host, try again later';
}


