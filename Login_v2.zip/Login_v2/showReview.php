<?php

session_start();
include 'sessionTime.php';
if ($_SESSION['email'] == "Admin@Admin.com") {
    // do nothing, theres no need to!
    include 'adminNavbar.php';
} else if ($_SESSION['email']) {
    // do nothing, theres no need to!
    include 'LoggedInNavbars.php';
} else {
    header('Location: Login.php'); //redirect back to login.php so users can access any info
}

// only fetching data, simple query.
$conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");

$userID = $_SESSION["id"];


$query = "SELECT reviewdescription FROM reviews WHERE userID = '$userID' AND BookingID='{$_POST["BookingID"]}' AND Date='{$_POST["Date"]}' AND Time='{$_POST["Time"]}' AND endtime='{$_POST["Endtime"]}'";

$res = $conn->query($query);
while ($row = $res->fetch_assoc()) {

    echo "<tr>";

    $reviewdescription = $row['reviewdescription'];

    echo "</tr>";
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>DomesticHelper</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="images/icons/favicon.ico" />
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!--===============================================================================================-->

    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">

    <style>
        .wrap-login100 {
            width: 600px;
            height: 1105px;
            margin-bottom: 125px;
        }

        .wrap-input100 {
            width: 25%;
        }

        .center {
            width: 25%;
            text-align: center;

            margin-left: 80%;
        }

        .dateTime {
            width: 175%;
        }

        .timepicker {
            border: 1px solid;
        }

        .timepicker2 {
            border: 1px solid;
        }

        .txt2 {
            bottom: 0;
            right: 0;
        }

        .full-width {
            width: 100%;
        }

        fieldset,
        label {
            margin: 0;
            padding: 0;
        }


        h1 {
            font-size: 1.5em;
            margin: 10px;
        }

        /****** Style Star Rating Widget *****/

        .rating {
            border: none;
            float: left;
        }

        .rating>input {
            display: none;
        }

        .rating>label:before {
            margin: 5px;
            font-size: 1.25em;
            font-family: FontAwesome;
            display: inline-block;
            content: "\f005";
        }

        .rating>.half:before {
            content: "\f089";
            float: left;

        }

        .rating>label {
            color: #FFD700;
            float: left;
        }

        /***** CSS Magic to Highlight Stars on Hover *****/

        .rating>input:checked~label,
        /* show gold star when clicked */
        .rating:not(:checked)>label:hover,
        /* hover current star */
        .rating:not(:checked)>label:hover~label {
            color: #FFD700;
        }

        /* hover previous stars in list */

        .rating>input:checked+label:hover,
        /* hover current star when changing rating */
        .rating>input:checked~label:hover,
        .rating>label:hover~input:checked~label,
        /* lighten current selection */
        .rating>input:checked~label:hover~label {
            color: #FFED85;
        }

        textarea {
            width: 100%;
            height: 150px;
            padding: 12px 20px;
            box-sizing: border-box;
            border: 2px solid #ccc;
            border-radius: 4px;
            background-color: #f8f8f8;
            font-size: 16px;
            resize: none;
        }
    </style>



</head>

<script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>

<body>


    <script>
        function myFunction() {

            window.location.replace("https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/Profile.php");

        }
    </script>

    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100">
                <form class="login100-form validate-form p-b 20" method="post">
                    <span class="login100-form-title">
                        Showing Review
                    </span>

                    <p>Service Name</p>
                    <div class="wrap-input100 validate-input full-width">
                        <input class="input100" name="servicename" type="servicename" id="servicename" value="<?php print_r($_POST['servicename']); ?>" required readonly="readonly">
                        <span class="focus-input100"></span>
                    </div>


                    <p>Service Description</p>
                    <div class="wrap-input100 validate-input full-width">
                        <input class="input100" name="servicedesc" type="servicedesc" id="servicedesc" value="<?php print_r($_POST['servicedesc']); ?>" required readonly="readonly">
                        <span class="focus-input100"></span>
                    </div>


                    <p>Service Location</p>
                    <div class="wrap-input100 validate-input full-width">
                        <input class="input100" name="location" type="location" id="location" value="<?php print_r($_POST['location']); ?>" required readonly="readonly">
                        <span class="focus-input100"></span>
                    </div>

                    <p>Rating Score</p> <!-- Credit for Code: James Barnett VIA Codepen.io, source link: https://codepen.io/jamesbarnett/pen/najzYK -->

                    <?php
                    $stmt = $conn->prepare("SELECT rating FROM reviews WHERE BookingID = ? AND userID = ?");

                    if ($stmt) {
                        $bookingID = $_POST["BookingID"];
                        $userID = $_SESSION['id'];
                        $stmt->bind_param("ii", $bookingID, $userID);
                        $stmt->execute();
                        $stmt->bind_result($rating);
                        $rating = print_r($rating);
                        while($stmt->fetch()) {
                            
                            echo "<fieldset class=rating>";
                            for ($i = 0; $i < $rating; $i++) {
                             if($i + 1 > $rating){
                               
                                echo "<input type=radio name=rating />" . "</input><label class=half></label>";
                                
                             } else{
                                echo "<input type=radio name=rating />" . "</input><label class=full></label>";
                             }
                            }
                            
                            echo "</fieldset>";
                        } $stmt->close();

                    }

                    ?>
                    <br>
                    <br>

                    <p>Offered By</p>
                    <div class="wrap-input100 validate-input">
                        <input class="input100" name="acceptedBy" type="acceptedBy" id="acceptedBy" value="<?php print_r($_POST['acceptedBy']); ?>" readonly="readonly">
                        <span class="focus-input100"></span>
                    </div>


                    <!-- pass the id through for the service but make it invisible on the viewService screen -->
                    <input class="input100" name="ServiceID" type="hidden" id="ServiceID" value="<?php print_r($_POST['ServiceID']); ?>" readonly="readonly">
                    <input class="input100" name="EmpID" type="hidden" id="EmpID" value="<?php print_r($_POST['EmpID']); ?>" readonly="readonly">
                    <span class="focus-input100"></span>

                    <div>
                        <p>Date</p>
                        <input class="input100" name="Date" id="Date" value="<?php print_r($_POST['Date']); ?>" readonly="readonly">
                    </div>
                    <div>
                        <p>Time</p>
                        <input class="input100" name="Time" id="Time" value="<?php print_r($_POST['Time']); ?>" readonly="readonly">
                    </div>

                    <div>
                        <p>End Time</p>
                        <input class="input100" name="Endtime" id="Endtime" value="<?php print_r($_POST['Endtime']); ?>" readonly="readonly">
                    </div>


                    <textarea class="reviewdescription" name="reviewdescription" id="reviewdescription" placeholder="<?php print_r($reviewdescription); ?>" readonly="readonly" disabled></textarea>
                    <br>
                    <br>
                    <div class="center">

                        <div class="wrap-login100-form-btn">

                            <div class="login100-form-bgbtn"></div>



                        </div>

                        <a class="txt2 p-b 20" href="Profile.php">
                            Go back
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- declare our AJAX function, once register button is clicked, confirm entered detials match database -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
    <script type="text/javascript">


    </script>


</body>

</html>