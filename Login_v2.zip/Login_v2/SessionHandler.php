<!-- Session done from tutorial video: source to video is: https://www.youtube.com/watch?v=vESwDXV81F0 -->

<!-- initialise session variable, linked to Login.php -->
<?php
session_start();
include 'setup.php';

if ($_SESSION['email']) {

    // redirect to the guide page, can change later to about page
    header("Refresh:2; url=Services.php");
} else {
    header('Location: Login.php'); //redirect back to login.php so users can access any info
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <style>
        body {
            text-align: center;
        }
    </style>

<body>
    <!-- display the email variable onbtained from the Login form email section and print out, page is only accessible if logged in. -->



    <script>
        Swal.fire({
            icon: 'success',
            title: 'Welcome <?php echo $_SESSION['email'] ?>, redirecting...',
            showConfirmButton: false,
            timer: 2000
        }).then(function() {
            window.location = "https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/Services.php";
        });
    </script>



</body>
</head>