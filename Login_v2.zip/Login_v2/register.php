<?php

require_once('setup.php');
include 'Navbars.php';

$conn = mysqli_connect("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20") or die("something went wrong, please try again!");

if (isset($_POST['submit'])) {

	$stmt = $conn->prepare("SELECT fname, sname, address, phoneno, postcode, email, password, gender, DateOfBirth, City FROM users WHERE email = ?");

	if ($stmt) {

		$currentdate = date("Y-m-d");
		$DOBVerify = date('Y-m-d', strtotime('-18 years', strtotime($currentdate)));


		$fname = $_POST['fname'];
		$sname = $_POST['sname'];
		$address = $_POST['address'];
		$phoneno = $_POST['phoneno'];
		$postcode = $_POST['postcode'];
		$email = $_POST['email'];
		$gender = $_POST['gender'];
		$password = $_POST['password'];
		$DOB = $_POST['DOB'];
		$City = $_POST['City'];
		$hash = password_hash($password, PASSWORD_BCRYPT);

		$stmt->bind_param("s", $email);
		$stmt->execute();
		$stmt->bind_result($fname, $sname, $address, $phoneno, $postcode, $email, $hash, $gender, $DOB, $City);
		$stmt->store_result();
		$stmt->fetch();
		$count = $stmt->num_rows;
		if ($count > 0) {
?>
			<script>
				Swal.fire({
					icon: 'error',
					title: 'Oops...',
					text: 'Email already exists in our database, please try a different email address.',
					showConfirmButton: false,
					timer: 4000
				})
			</script>


			<?php
		} else if (strpos($gender, 'M') !== false or strpos($gender, 'm') !== false or strpos($gender, 'F') !== false or strpos($gender, 'f') !== false or strpos($gender, 'O') !== false or strpos($gender, 'o') !== false) {


			//Source Credit for preg_match function for my needs - StackOverflow Thread - https://stackoverflow.com/questions/11873990/create-preg-match-for-password-validation-allowing/11874336#11874336 - Comment by r3bel 
			if (!preg_match('/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]{8,12}$/', $password)) {
				echo 'the password does not meet the requirements!';
			} else {



				if ($DOB <= $DOBVerify) {
			?>
					<script>
						Swal.fire({
							icon: 'success',
							title: 'Account Created',
							text: 'you can now login as a user.',
							showConfirmButton: false,
							timer: 4000
						}).then(function() {
							window.location = "https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/Login.php";
						});
					</script> <?php
								$stmt = $conn->prepare("INSERT INTO users (fname,sname,address,phoneno,postcode,email,gender,password,DateOfBirth,City) VALUES (?,?,?,?,?,?,?,?,?,?)");
								$stmt->bind_param("ssssssssss", $_POST["fname"], $_POST["sname"], $_POST["address"], $_POST["phoneno"], $_POST["postcode"], $_POST["email"], $_POST["gender"], $hash, $_POST["DOB"], $_POST["City"]);
								$stmt->execute();
								$stmt->close();
							} else {
								?>
					<script>
						Swal.fire({
							icon: 'warning',
							text: 'you must be over 18 years old to use this service.',
							showConfirmButton: false,
							timer: 4000
						})
					</script>


			<?php
							}
						}


			?>
		<?php

		} else {
		?>
			<script>
				Swal.fire({
					icon: 'info',
					title: 'Incorrect Gender Selection.',
					text: 'Please only enter M for Male, F for Female, or O for Other.',
					showConfirmButton: true,

				})
			</script>


<?php
		}
	}
}

?>

<!DOCTYPE html>
<html lang="en">

<head>

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>DomesticHelper</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico" />
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<!--===============================================================================================-->
</head>

<body>

	<script>
		//function to show password or not on register page.
		function showPass() {
			var password_element = document.getElementById("password");
			if (password_element.type === "password") {
				password_element.type = "text";
			} else {
				password_element.type = "password";
			}
		}
	</script>
	<script>
		function passwordInfo() {
			Swal.fire({
				icon: 'info',
				title: 'Password Criteria Minimum:',
				text: '1 Uppercase & Lowercase letter, 1 number and 1 special character',
				
			})
		}
	</script>

	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form" method="post">
					<span class="login100-form-title p-b-26">
						Domestic Helper
					</span>
					<span class="login100-form-title p-b-48">
						<img src="../logo/DomesticLogo2.png" style="height: 200px; width: 250px">
					</span>

					<div class="wrap-input100 validate-input">
						<p>First Name</p>
						<input class="input100" name="fname" type="fname" id="fname" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<p>Last Name</p>
						<input class="input100" name="sname" type="sname" id="sname" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<p>Address</p>
						<input class="input100" name="address" type="address" id="address" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<p>Phone Number</p>
						<input class="input100" name="phoneno" type="phoneno" id="phoneno" required minlength="11" maxlength="11">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<p>Postcode</p>
						<input class="input100" name="postcode" type="postcode" id="postcode" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<p>City</p>
						<input class="input100" name="City" type="City" id="City" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Valid email is: please use correct email format, eg: johndoe@example.com">
						<p>Email</p>
						<input class="input100" name="email" type="email" id="email" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<p>Gender (M, F or O)</p>
						<input class="input100" name="gender" type="gender" id="gender" required maxlength="1" data-validate="please enter M for Male or F for Female">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password" required>
						<p>Password<a ><img src="https://www.kindpng.com/picc/m/210-2109960_info-info-icon-png-white-transparent-png.png" height="20px" width="20px" onclick="passwordInfo()" /></a></p>
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye" onclick="showPass()"></i>
						</span>
						<input class="input100 form-control input_pass" type="password" name="password" id="password">
						<span class="focus-input100"></span>
					</div>

					<div>
						<p>Date of Birth</p>
						<input type="date" id="DOB" name="DOB" required>
					</div>



					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" type="submit" name="submit" href="login.php">
								Sign up
							</button>
						</div>
					</div>

					<div class="text-center p-t-115">
						<a class="txt2" href="login.php">
							Go back
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>

	<!-- declare our AJAX function, once register button is clicked, confirm entered detials match database -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script type="text/javascript">


	</script>


</body>

</html>