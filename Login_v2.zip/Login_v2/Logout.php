<?php
session_start();
require_once("setup.php");

$logoutvalue = 0;
                    $stmt = $conn->prepare("UPDATE users SET isLoggedIn = ? WHERE email = ?");
					$stmt->bind_param("is", $logoutvalue, $_SESSION["email"]);
					$stmt->execute();
					$stmt->close();

                    $stmt2 = $conn->prepare("UPDATE employee SET isLoggedIn = ? WHERE email = ?");
					$stmt2->bind_param("is", $logoutvalue, $_SESSION["email"]);
					$stmt2->execute();
					$stmt2->close();

if(session_destroy()){
   header("location: login.php");
}

?>