<?php
require_once('setup.php'); ?>
<?php

if (isset($_POST)) {

	$fname 				= $_POST['fname'];
	$sname 				= $_POST['sname'];
	$address			= $_POST['address'];
	$postcode			= $_POST['postcode'];
	$email				= $_POST['email'];
	$password			= $_POST['password'];
	$saltstring 		= 	"324t4gvdsfv3qwfdwasf3";
	$password 			= 	$_POST['password'] . $saltstring;
	$password 			= sha1($password);


	$connect = mysqli_connect("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");

	$dup = mysqli_query($connect, "SELECT * FROM users WHERE email = '$email' ");

	if (mysqli_num_rows($dup) > 0) {


		echo 'User already exists, Please enter another email address';
	} else {

		$sql = "INSERT INTO users (fname, sname, address, postcode, email, password) VALUES(?,?,?,?,?,?)";
		$stmtinsert = $database->prepare($sql);
		$result = $stmtinsert->execute([$fname, $sname, $address, $postcode, $email, $password]);
		if ($result) {
			echo 'user added to the database!';
		} else {
			echo 'There were erros while saving the data.';
		}
	}
} else {
	echo 'No data';
}
?>