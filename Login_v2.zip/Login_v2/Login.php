<!-- Credit for template use ; Login Form V2 by Colorlib, free template, see here https://colorlib.com/wp/template/login-form-v2/ -->
<!-- Credit for responsive navbar: How to create a responsive top navigation bar by W3Schools, source is here : https://www.w3schools.com/howto/howto_js_topnav_responsive.asp -->

<?php

session_start();

include 'Navbars.php'; 
require_once("setup.php"); 
if(isset($_SESSION)){
    // unset the session, prevent session still being active when going for newpass.php to login.php, UNLESS THE EMAIL IS SET, this is fine.
		session_unset();					
}


if(isset($_SESSION['email'])){
    // do nothing, theres no need to!
	
	header("Location: SessionHandler.php");
}

else{
	// nothing
	
}


$conn = mysqli_connect("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20") or die ("something went wrong, please try again!");


	if (isset($_POST['submit'])){
		
		$email    = $conn->real_escape_string($_POST['email']); // prevent SQL injection, never pass post directly!
		$password = $conn->real_escape_string($_POST['password']); // prevent SQL injection, never pass post directly!
		$sql = $conn->query("SELECT email, password, id FROM users where email = '$email'");
		$sql2 = $conn->query("SELECT email, password, EmpID FROM employee where email = '$email'");

		if($sql->num_rows > 0){
			
			$data = $sql->fetch_array();
			if(password_verify($password, $data['password'])){

				$_SESSION["email"] = $email;

				// cast the id to an int, so it returns in the array as an int and not an object
				$id = (int)$data['id'];
				$_SESSION['id'] = $data['id'];
				
				echo "welcome " .  $_SESSION['email'];
				header("Location: SessionHandler.php");
				
				}

				
				else{
					echo '<script language="javascript">';
					echo 'alert("incorrect details, please try again.")';
					echo '</script>';
				}
			}
			else if($sql2->num_rows > 0){
				$data = $sql2->fetch_array();
				if(password_verify($password, $data['password'])){

					$_SESSION["email"] = $email;
	
					// cast the id to an int, so it returns in the array as an int and not an object
					$id = (int)$data['EmpID'];
					$_SESSION['EmpID'] = $data['EmpID'];
					
					echo "welcome " .  $_SESSION['email'];
					header("Location: SessionHandler.php");
					
					}

			}
		}
			
			
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<style>

#bottomnav {
  background-color: #333;
  overflow: hidden;
  
  bottom: 0;
  width: 100%;
}
.footertext{
  text-align: center;
}

	</style>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>DomesticHelper</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>


<body href="images/loginbackground.jpg">
<script>
	function func(){
	var password_element = document.getElementById("password");
	if(password_element.type === "password"){
		password_element.type = "text";
	} else{
		password_element.type = "password";
	}
}
</script>

	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form" method="post" action="Login.php">
					<span class="login100-form-title p-b-26">
						Domestic Helper<br>User
					</span>
					<span class="login100-form-title p-b-48">
					<img src="../logo/DomesticLogo2.png" style="height: 200px; width: 250px">
					</span>

					<div class="wrap-input100 validate-input" data-validate = "Valid email is: please use correct email format, eg: johndoe@example.com">
						<p>Email</p>
						<input class="input100" name="email" type="email" id="email" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password" required>
						<p>Password</p>
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye" onclick="func()"></i>
						</span>
						<input class="input100 form-control input_pass" type="password" name="password" id="password">
						<span class="focus-input100"></span>
					</div>

					<div class="checkbox">
      					<label class="customer-control-label" for="customControlInLine"> <input type="checkbox" name="rememberuser" class="custom-contrtol-input"> Remember me</label>
    				</div>

					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" id="Sign_in" name="submit" type="submit">
								Login
							</button>
						</div>
					</div>

					<div class="text-center p-t-115">
						<span class="txt1">
							Don’t have an account?
						</span>

						<a class="txt2" href="register.php">
							Sign Up
						</a>
						<br>
						<br>
						<a class="txt2" href="passreset.php">
							Forgotten password?
						</a>

					</div>
				</form>
			</div>
		</div>
	</div>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<script>
	function myFunction() {
  	var x = document.getElementById("myTopnav");
  	if (x.className === "topnav") {
    x.className += " responsive";
  	} else {
    x.className = "topnav";
  	}
	}
</script>
	

	

</body>

<div>
<p class="footertext" style="color:white" id="bottomnav">Website created by Sam, Tope, Saahil & Esther</p>

</div>
</html>