<?php
//start the session and include the current session time
session_start();
include 'sessionTime.php';
if ($_SESSION['EmpID']) {
    // include the employee navbar if the session already has an employee id in it.
    include 'adminNavbar.php';
} else {
    header('Location: homepage.php'); // else, redirect back to homepage so users can access any info
}
//any session details that may be set, unset them.
if (isset($_SESSION['servicename'])) {
    unset($_SESSION['servicename'], $_SESSION['servicedesc'], $_SESSION['location'], $_SESSION['rating'], $_SESSION['price'], $_SESSION['employeename']);
}
//if the submit button is pressed, accept the booking, otherwise throw error.
if (isset($_POST['submit'])) {

    $bookingID = $_POST['BookingID'];
    $servicename = $_POST['servicename'];
    $servicedesc = $_POST['servicedesc'];
    $userID = $_POST['id'];
    $time = $_POST['Time'];
    $date = $_POST['Date'];
    $endtime = $_POST['Endtime'];
    $name = $_SESSION['fname'] . ' ' . $_SESSION['sname'];
    $id = $_SESSION['EmpID'];
    $location = $_POST['location'];
    $ServiceID = $_POST['ServiceID'];

    $conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20"); //database connection
    $sql = $conn->query("SELECT Time, Date, BookingID FROM Bookings WHERE Time = '$time' AND Date = '$date' AND BookingID = '$bookingID'"); //query the database

    //accept the booking once found in the database, alert user.
    if ($sql->num_rows > 0) {
?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Booking accepted.',
                showConfirmButton: false,
                timer: 2000
            });
        </script>
    <?php
        //delete it from the bookings table, move over to activebookings.
        $conn->query("DELETE FROM Bookings WHERE Time = '$time' AND Date = '$date' AND EmpID = '$id'");
        $conn->query("INSERT INTO activeBookings (BookingID, servicename, servicedesc, Date, Time, endtime, EmpID, acceptedBy, id, location, ServiceID) VALUES ('$bookingID', '$servicename', '$servicedesc', '$date', '$time', '$endtime','$id', '$name', '$userID', '$location', '$ServiceID')");
    } else {
        // throw error if there was an issue.
    ?>
        <script>
            Swal.fire({
                icon: 'Error.',
                title: 'Something went wrong.',
                showConfirmButton: false,
                timer: 2000
            });
        </script>
    <?php
    }
}
//if markJobComplete button is pressed, move said job from activeBookings to completedBookings table. 
if (isset($_POST['markJobComplete'])) {


    $customID = $_POST['CustomID'];
    $bookingID = $_POST['BookingID'];
    $servicename = $_POST['servicename'];
    $ServiceID = $_POST['ServiceID'];
    $servicedesc = $_POST['servicedesc'];
    $time = $_POST['Time'];
    $date = $_POST['Date'];
    $endtime = $_POST['Endtime'];
    $id = $_SESSION['EmpID'];
    $userID = $_POST['id'];
    $location = $_POST['location'];
    $name = $_SESSION['fname'] . ' ' . $_SESSION['sname'];

    $conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20"); //database connection
    $sql = $conn->query("SELECT BookingID, CustomID FROM activeBookings WHERE BookingID = '$bookingID' OR CustomID = '$customID'"); //search database for matching row BookingID or CustomID
    //show alert to user if a row matching the details from query is found. then execute delete query.
    if ($sql->num_rows > 0) {
    ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Booking marked as complete',
                showConfirmButton: false,
                timer: 3000
            });
        </script>
        <?php
        $conn->query("DELETE FROM activeBookings WHERE Time = '$time' AND Date = '$date' AND (BookingID = '$bookingID' OR CustomID = '$customID') AND EmpID = '$id'");
        //if we know that bookingID is null, we are dealing with a custom request, so we can insert into completedBookings the correct details based on the if statement below.
        if ($bookingID == NULL) {

            $conn->query("INSERT INTO completedBookings (CustomID, servicename, servicedesc, Date, Time, endtime, EmpID, id, location, acceptedBy) VALUES ('$customID', '$servicename', '$servicedesc', '$date', '$time', '$endtime','$id','$userID', '$location', '$name')");
        } else {
            $conn->query("INSERT INTO completedBookings (ServiceID, BookingID, servicename, servicedesc, Date, Time, endtime, EmpID, id, location, acceptedBy, LeftReview) VALUES ('$ServiceID', '$bookingID', '$servicename', '$servicedesc', '$date', '$time', '$endtime','$id','$userID', '$location', '$name', 'No')");
        }
    } else {
        //error if no such booking exists in database.
        ?>
        <script>
            Swal.fire({
                icon: 'Error.',
                title: 'Something went wrong.',
                showConfirmButton: false,
                timer: 2000
            });
        </script>
    <?php
    }
}
//same as above process but with custom requests.
if (isset($_POST['customRequests'])) {

    $customID = $_POST['CustomID'];
    $servicename = $_POST['servicename'];
    $servicedesc = $_POST['servicedesc'];
    $time = $_POST['Time'];
    $date = $_POST['Date'];
    $endtime = $_POST['Endtime'];
    $id = $_SESSION['EmpID'];
    $location = $_POST['location'];
    $price = $_POST['price'];
    $userID = $_POST['requestedByUser'];
    $name = $_SESSION['fname'] . ' ' . $_SESSION['sname'];

    $conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");
    $sql = $conn->query("SELECT * FROM customRequests");

    if ($sql->num_rows > 0) {

    ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Booking accepted.',
                showConfirmButton: false,
                timer: 2000
            });
        </script>
    <?php
    //delete from custom requests table and place into the activeBookings table when accepting a booking.
        $conn->query("DELETE FROM customRequests WHERE Time = '$time' AND Date = '$date' AND servicename = '$servicename' AND servicedesc = '$servicedesc' AND requestedByUser = '$userID'");
        $conn->query("INSERT INTO activeBookings (CustomID, servicename, servicedesc, Date, Time, endtime, EmpID, id, location, acceptedBy) VALUES ('$customID','$servicename', '$servicedesc', '$date', '$time', '$endtime','$id','$userID', '$location', '$name')");
    } else {
        //otherwise show error.
    ?>
        <script>
            Swal.fire({
                icon: 'Error.',
                title: 'Something went wrong.',
                showConfirmButton: false,
                timer: 2000
            });
        </script>
<?php
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>DomesticHelper</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- importing use of bootstrap and fontawesome -->
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="images/icons/favicon.ico" />
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!--===============================================================================================-->
    <style>
        /* styling all our elements, mostly centering stuff like profile.php */
        h4,
        h5 {
            text-align: center;
        }

        body {
            text-align: center;
            background: url(https://wallpaperaccess.com/full/3898677.jpg);
            background-repeat: no-repeat;
            background-size: 1920px 1080px;
        }

        table,
        th,
        td {
            border: 1px solid black;

        }

        .tablecenter {
            margin-left: auto;
            margin-right: auto;
        }

        #customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 55%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers tr:nth-child(ODD) {
            background-color: #DDD;
        }

        #customers tr:hover {
            background-color: #ddd;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: center;
            background-color: #04AA6D;
            color: white;
        }

        /* css button styles, credit to HTML Goodies - code found here : https://www.htmlgoodies.com/css/css-button-styles/ */

        .viewButton {
            display: inline-block;
            background-color: #32CD32;
            border-radius: 10px;
            border: 3px double #cccccc;
            color: white;
            text-align: center;
            font-size: 13px;
            padding: 20px;
            height: 20px;
            width: 200px;
            transition: all 0.5s;
            cursor: pointer;
            margin: 5px;
            line-height: 0px;
        }

        .viewButton input {
            cursor: pointer;
            display: inline-block;
            position: relative;
            transition: 0.5s;
        }

        .viewButton input:after {
            content: '0bb';
            position: absolute;
            opacity: 0;
            top: 0;
            right: -20px;
            transition: 0.5s;
        }

        .viewButton:hover {
            background-color: #FFFFFF;
            color: black;
        }

        .viewButton:hover input {
            padding-right: 25px;

        }

        .viewButtonhover input:after {
            opacity: 1;
            right: 0;
        }

        table,
        th,
        td {
            border: 1px solid black;
            text-align: center;
        }

        .completeform {
            width: 200px;
        }

        #leaveReview {
            background-color: orange;
        }

        #noReview {
            background-color: #F52D2D;
        }
    </style>

<body>
    <h4>Profile page for user: <?php echo $_SESSION['fname'] . " " . $_SESSION['sname'];  ?></h4> <!-- show employees name in the profile -->
    <br>
    <a class="btn btn-primary glyphicon glyphicon-search" data-toggle="collapse" href="#collapseExample4" role="button" aria-expanded="false" aria-controls="collapseExample">
        <h4>Bookings Requested</h4>
        &#8595;
    </a>

    <div class="collapse" id="collapseExample4">
        <div class="card-body">
            <table class="tablecenter" id="customers"> <!-- table where we see all booking information -->
                <thead>
                    <tr>
                        <th>BookingID</th>
                        <th>Service Name</th>
                        <th>Service Description</th>
                        <th>Date</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>User ID</th>
                        <th>Location</th>
                        <th>Book</th>
                    </tr>
                </thead>

                <?php
                $conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20"); // connect to DB
                $id = $_SESSION['EmpID']; //bind employee id to variable

                if ($conn->connect_error) {
                    die("Connection error: " . $conn->connection_error);
                }
                //find any bookings requested related to that id and display each row in the table
                $query = "SELECT BookingID, servicename, servicedesc, Date, Time, endtime, ServiceID, EmpID, id, location FROM Bookings WHERE EmpID = '$id'";
                $res = $conn->query($query);

                while ($row = $res->fetch_assoc()) {

                    echo "<tr>";
                    echo "<td>" . $row['BookingID'] . " " . "</td>";
                    echo "<td>" . $row['servicename'] . " " . "</td>";
                    echo "<td>" . $row['servicedesc'] . " " . "</td>";
                    echo "<td>" . $row['Date'] . " " . "</td>";
                    echo "<td>" . $row['Time'] . " " . "</td>";
                    echo "<td>" . $row['endtime'] . " " . "</td>";
                    echo "<td>" . $row['id'] . " " . "</td>";
                    echo "<td>" . $row['location'] . " " . "</td>";

                    //give each row a button in style of a form to accept that row as a booking.

                    echo "<td><form method=post>
                                 <input name=BookingID type=hidden value='" . $row['BookingID'] . "'>
                                 <input name=ServiceID type=hidden value='" . $row['ServiceID'] . "'>
                                 <input name=servicename type=hidden value='" . $row['servicename'] . "'>
                                 <input name=servicedesc type=hidden value='" . $row['servicedesc'] . "'>
                                 <input name=Time type=hidden value='" . $row['Time'] . "'>
                                 <input name=Endtime type=hidden value='" . $row['endtime'] . "'>
                                 <input name=Date type=hidden value='" . $row['Date'] . "'>
                                 <input name=id type=hidden value='" . $row['id'] . "'>
                                 <input name=location type=hidden value='" . $row['location'] . "'>
                                
                                 <input type=submit name=submit class=viewButton value=Accept></form></td>";
                    echo "</tr>";
                }
                $conn->close(); //close the connection to the DB
                ?>
            </table>
        </div>
    </div>


    <a class="btn btn-primary glyphicon glyphicon-search" data-toggle="collapse" href="#collapseExample3" role="button" aria-expanded="false" aria-controls="collapseExample">
        <h4>Current Jobs</h4>
        &#8595;
    </a>

    <div class="collapse" id="collapseExample3">
        <div class="card-body">
            <table class="tablecenter" id="customers"> <!-- table where we see all the current jobs -->
                <thead>
                    <tr>
                        <th>BookingID</th>
                        <th>CustomID</th>
                        <th>Service Name</th>
                        <th>Service Description</th>
                        <th>Date</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>User ID</th>
                        <th>Location</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <?php
                 $conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20"); // connect to DB
                 $id = $_SESSION['EmpID']; //bind employee id to variable
 
                 if ($conn->connect_error) {
                     die("Connection error: " . $conn->connection_error);
                 }
                //show in a table, any activeBookings related to the current ID of the employee logged in.
                $query = "SELECT CustomID, BookingID, ServiceID, servicename, servicedesc, Date, Time, endtime, EmpID, id, location FROM activeBookings WHERE EmpID = '$id'";
                $res = $conn->query($query);

                while ($row = $res->fetch_assoc()) {

                    echo "<tr>";

                    echo "<td>" . $row['BookingID'] . " " . "</td>";
                    echo "<td>" . $row['CustomID'] . " " . "</td>";
                    echo "<td>" . $row['servicename'] . " " . "</td>";
                    echo "<td>" . $row['servicedesc'] . " " . "</td>";
                    echo "<td>" . $row['Date'] . " " . "</td>";
                    echo "<td>" . $row['Time'] . " " . "</td>";
                    echo "<td>" . $row['endtime'] . " " . "</td>";
                    echo "<td>" . $row['id'] . " " . "</td>";
                    echo "<td>" . $row['location'] . " " . "</td>";

                    //form button that when clicked will mark the job as complete, delete it from this table and place it in the completed bookings section 
                    echo "<td><form method=post>
                        <input name=BookingID type=hidden value='" . $row['BookingID'] . "'>
                        <input name=CustomID type=hidden value='" . $row['CustomID'] . "'>
                        <input name=ServiceID type=hidden value='" . $row['ServiceID'] . "'>
                        <input name=servicename type=hidden value='" . $row['servicename'] . "'>
                        <input name=servicedesc type=hidden value='" . $row['servicedesc'] . "'>
                        <input name=Time type=hidden value='" . $row['Time'] . "'>
                        <input name=Endtime type=hidden value='" . $row['endtime'] . "'>
                        <input name=Date type=hidden value='" . $row['Date'] . "'>
                        <input name=id type=hidden value='" . $row['id'] . "'>
                        <input name=location type=hidden value='" . $row['location'] . "'>
                            
                        <input type=submit name=markJobComplete class=viewButton value='Mark As Complete'></form></td>";
                    echo "</tr>";
                }
                $conn->close(); //close the connection to DB
                ?>
            </table>
        </div>
    </div>

    <a class="btn btn-primary glyphicon glyphicon-search" data-toggle="collapse" href="#collapseExample2" role="button" aria-expanded="false" aria-controls="collapseExample">
        <h4>Custom Requests</h4>
        &#8595;
    </a>

    <div class="collapse" id="collapseExample2">
        <div class="card-body">
            <table class="tablecenter" id="customers"> <!-- table that shows any custom request bookings -->
                <thead>
                    <tr>
                        <th>CustomID</th>
                        <th>Service Name</th>
                        <th>Service Description</th>
                        <th>Date</th>
                        <th>Location</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Price Offered</th>
                        <th>Requested by User</th>
                        <th>Accept</th>
                    </tr>
                </thead>

                <?php
                $conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20"); // connect to DB
                $id = $_SESSION['EmpID']; //bind employee id to variable

                if ($conn->connect_error) {
                    die("Connection error: " . $conn->connection_error);
                }

                //query to find all custom requests, since theyre available to ALL employees to accept and display each row of the database in the below table.
                $query = "SELECT * FROM customRequests";
                $res = $conn->query($query);

                while ($row = $res->fetch_assoc()) {

                    echo "<tr>";

                    echo "<td>" . $row['CustomID'] . " " . "</td>";
                    echo "<td>" . $row['servicename'] . " " . "</td>";
                    echo "<td>" . $row['servicedesc'] . " " . "</td>";
                    echo "<td>" . $row['Date'] . " " . "</td>";
                    echo "<td>" . $row['location'] . " " . "</td>";
                    echo "<td>" . $row['Time'] . " " . "</td>";
                    echo "<td>" . $row['endtime'] . " " . "</td>";
                    echo "<td>" . $row['price'] . " " . "</td>";
                    echo "<td>" . $row['requestedByUser'] . " " . "</td>";

                    //button form that when clicked, will allow the employee to accept the job and move it into their ongoing bookings section.
                    echo "<td><form method=post>
                        <input name=CustomID type=hidden value='" . $row['CustomID'] . "'>
                        <input name=servicename type=hidden value='" . $row['servicename'] . "'>
                        <input name=servicedesc type=hidden value='" . $row['servicedesc'] . "'>
                        <input name=Time type=hidden value='" . $row['Time'] . "'>
                        <input name=Endtime type=hidden value='" . $row['endtime'] . "'>
                        <input name=Date type=hidden value='" . $row['Date'] . "'>
                        <input name=location type=hidden value='" . $row['location'] . "'>
                        <input name=price type=hidden value='" . $row['price'] . "'>
                        <input name=requestedByUser type=hidden value='" . $row['requestedByUser'] . "'>
            
                        <input type=submit name=customRequests class=viewButton value=Accept></form></td>";
                    echo "</tr>";
                }
                $conn->close(); //close database connection
                ?>
            </table>
        </div>
    </div>

    <a class="btn btn-primary glyphicon glyphicon-search" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
        <h4>Completed Bookings</h4>
        &#8595;
    </a>

    <div class="collapse" id="collapseExample">
        <div class="card-body">
            <table class="tablecenter" id="customers"> <!-- table to show any completed bookings the employee has done -->
                <thead>
                    <tr>
                        <th>BookingID</th>
                        <th>Custom ID</th>
                        <th>Service Name</th>
                        <th>Service Description</th>
                        <th>Location</th>
                        <th>Date</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>User ID</th>
                        <th>Review</th>
                    </tr>
                </thead>

                <?php
                 $conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20"); // connect to DB
                 $id = $_SESSION['EmpID']; //bind employee id to variable
 
                 if ($conn->connect_error) {
                     die("Connection error: " . $conn->connection_error);
                 }

                 //query the database looking for all completed bookings that this employee has done, and display them in the table below in row format.
                $query = "SELECT * FROM completedBookings WHERE EmpID = '$id'";
                $res = $conn->query($query);

                while ($row = $res->fetch_assoc()) {

                    echo "<tr>";

                    echo "<td>" . $row['BookingID'] . " " . "</td>";
                    echo "<td>" . $row['CustomID'] . " " . "</td>";
                    echo "<td>" . $row['servicename'] . " " . "</td>";
                    echo "<td>" . $row['servicedesc'] . " " . "</td>";
                    echo "<td>" . $row['location'] . " " . "</td>";
                    echo "<td>" . $row['Date'] . " " . "</td>";
                    echo "<td>" . $row['Time'] . " " . "</td>";
                    echo "<td>" . $row['endtime'] . " " . "</td>";
                    echo "<td>" . $row['id'] . " " . "</td>";



                    // create if statement here, if a review already exists, insert a 'show review' button, otherwise, 'leave review button'
                    if (($row['LeftReview']) == 'No') {
                        echo "<td>" . "<input type=button class=viewButton id=leaveReview value='review pending'>" . "</td>";
                    } else if (($row['BookingID'] == null)) {
                        echo "<td>" . "<p>Review not available.</p>" . "</td>";
                    } else {
                        echo "<td><form action=showReview.php method=post>";
                        echo        "<input name=servicename type=hidden value='" . $row['servicename'] . "'>";
                        echo        "<input name=BookingID type=hidden value='" . $row['BookingID'] . "'>";
                        echo        "<input name=ServiceID type=hidden value='" . $row['ServiceID'] . "'>";
                        echo        "<input name=servicedesc type=hidden value='" . $row['servicedesc'] . "'>";
                        echo        "<input name=Time type=hidden value='" . $row['Time'] . "'>";
                        echo        "<input name=Endtime type=hidden value='" . $row['endtime'] . "'>";
                        echo        "<input name=Date type=hidden value='" . $row['Date'] . "'>";
                        echo        "<input name=location type=hidden value='" . $row['location'] . "'>";
                        echo        "<input name=id type=hidden value='" . $row['id'] . "'>";
                        echo "<input type=submit name=viewReview class=viewButton id=showReview value='show review'>";
                    }
                    echo "</tr>";
                }
                $conn->close();
                ?>
            </table>
        </div>
    </div>
</body>

</html>