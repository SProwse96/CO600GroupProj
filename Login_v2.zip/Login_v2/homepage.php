<?php
session_start();


include 'Navbars.php';

?>

<!DOCTYPE html>
<head>
    
<style>
img{
    width: 100%;
    height: auto;
}
h1 {
    text-align: center;
} 
p {
    text-align: center;
}
p.solid {border-style: solid;
         border-color: #555; 
         }

body {
    background: url(https://wallpaperaccess.com/full/3898677.jpg);
  background-repeat: no-repeat;
  width: 100%;
  height: 100%;
 }
 
 .line1 {
  font-size: 80px;
  position: absolute;
  top: 200px;
  left: 750px;
  font-family: sans-serif;
  color: black;
  
}
 
.line2 {
  font-size: 30px;
  position: absolute;
  top: 350px;
  left: 750px;
  
}

.line3 {
  font-size: 30px;
  position: absolute;
  top: 500px;
  left: 750px;
color: blue;
  
}
    
.line8 {
  font-size: 30px;
  position: absolute;
  top: 550px;
  left: 750PX;
color: blue;
  
}

.line4 {
  font-size: 30px;
  position: absolute;
  top: 600px;
  left: 750px;
color: blue;
  
}
.line9 {
  font-size: 30px;
  position: absolute;
  top: 650PX;
  left: 750px;
color: blue;
  
}
  
.line11 {
  font-size: 26px;
  position: absolute;
  top: 700PX;
  left: 750px;
  font-family: sans-serif;
  color: black;
  
}
  
  /* width: 40%; */
}

#bottomnav {
  background-color: #333;

  height: 50px;
  bottom: 0;
  margin-bottom: 0.5px;
  width: 100%;
}
</style>
</head>

<body>



 <div class="infographic">
<img src="images/homepage2.jpeg" class="photo" alt="cleaningcrew" width="800" height="400">
<div class="line1">Your Clean Home is our Business.</div>
<div class="line3"><button onclick="window.location.href='https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/Login.php';" type="submit" name="LU" value="activate">LOGIN FOR USER</button></div>
<div class="line8"><button onclick="window.location.href='https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/register.php';" type="submit" name="RU" value="activate">REGISTER FOR USER</button></div>
<div class="line4"><button onclick="window.location.href='https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/Loginemp.php';" type="submit" name="LE" value="activate">LOGIN FOR EMPLOYEE</button></div>
<div class="line9"><button onclick="window.location.href='https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/employeeRegister.php';" type="submit" name="RE" value="activate">REGISTER FOR EMPLOYEE</button></div>


<div class="line11">At Domestic Helpers, we aim to provide services in order to keep your home clean, we believe a clean home equates to happy life. Just book and leave the rest to us ! </div>
<div class="topnav" id="bottomnav">

<p class="footertext" style="color:white">Website created by Sam, Tope & Saahil</p>

</body>

