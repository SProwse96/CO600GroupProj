<?php
session_start();


include 'Navbars.php';

?>

<!DOCTYPE html>
<head>
<style>
img{
    width: 100%;
    height: auto;
}
h1 {
    text-align: center;
} 
p {
    text-align: center;
}
p.solid {border-style: solid;
         border-color: #474A8A; 
         }

body {background: url(https://htmlcolorcodes.com/assets/images/html-color-codes-color-tutorials-hero.jpg);
  background-repeat: no-repeat;
  width: 100%;
  height: 100%;
 }
 
 .line1 {
  font-size: 100px;
  position: absolute;
  top: 150px;
  left: 750px;
  font-family: "Times New Roman";
  color: red;
  
}
 
.line2 {
  font-size: 30px;
  position: absolute;
  top: 450px;
  left: 750px;
  
}

.line3 {
  font-size: 30px;
  position: absolute;
  top: 500px;
  left: 750px;
  
}
    

.line4 {
  font-size: 30px;
  position: absolute;
  top: 550px;
  left: 750px;
  
}
  
  /* width: 40%; */
}

#bottomnav {
  background-color: #333;
  overflow: hidden;
  height: 50px;
  bottom: 0;
  margin-bottom: 0.5px;
  width: 100%;
}
</style>
</head>
<body>
<br>
<br>
<br>
 <div class="infographic">
<img src="images/homepage2.jpeg" class="photo" alt="cleaningcrew" width="800" height="400">
<div class="line1">SLOGAN TO PUT HERE</div><br>
<div class="line2">Please select from one of the following options</div><br>
<div class="line3"><a href="https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/Login.php">LOGIN </div>
<div class="line4"><a href="https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/register.php">REGISTER </div>
<div class="topnav" id="bottomnav">
<p class="footertext" style="color:white">Website created by Sam, Tope, Saahil & Esther</p>
</div>
</body>

