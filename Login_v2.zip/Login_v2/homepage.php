<?php
//start the session 
session_start();



//if current session has id set, redirect to services.php otherwise if EmpID is set in the session, redirect to employee profile. else load regular navbars.
if (isset($_SESSION['id'])) {
  echo '<script type="text/javascript">';
  echo 'window.location.href="Services.php";';
  echo '</script>';
} elseif (isset($_SESSION['EmpID'])) {
  echo '<script type="text/javascript">';
  echo 'window.location.href="profileEmp.php";';
  echo '</script>';
} else {
  include 'Navbars.php';
}

?>

<!DOCTYPE html>

<head>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <title>DomesticHelper</title>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- imported stylesheets -->

  <!--===============================================================================================-->
  <link rel="icon" type="image/png" href="images/icons/favicon.ico" />
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="css/util.css">
  <link rel="stylesheet" type="text/css" href="css/main.css">
  <!--===============================================================================================-->
  <style>
    img {
      width: 100%;
      height: auto;
    }

    /* styling of headers and paragraphs */
    h1 {
      text-align: center;
    }

    p {
      text-align: center;
    }

    p.solid {
      border-style: solid;
      border-color: #555;
    }

    body {
      background: url(https://wallpaperaccess.com/full/3898677.jpg);
      background-repeat: no-repeat;
      width: 100%;
      height: 100%;
    }

    /* header of the homepage */
    .homepageHeader {
      font-size: 60px;
      text-align: center;
      font-family: sans-serif;
      color: black;

    }

    .line8,
    .line9,
    .line4,
    .line3 {
      font-size: 30px;
      color: blue;

    }

    .line11 {
      font-size: 26px;
      font-family: sans-serif;
      color: black;

    }

    /* styling of footer navbar */
    #bottomnav {
      background-color: #333;

      height: 50px;
      bottom: 0;
      margin-bottom: 0.5px;
      width: 100%;
    }

    /* positioning of buttons */
    .buttonDiv {
      margin: 0;
      position: absolute;
      top: 15%;
      left: 50%;
      -ms-transform: translate(-50%, -50%);
      transform: translate(-50%, -50%);
      text-align: center;
    }

    /* keep positon of the infographic relative to the size of the browser */
    .infographic {
      position: relative;
    }
  </style>
</head>

<body>


  <!-- where most of our details of this page are held, including buttons, headers, and paragraph details -->
  <div class="infographic">
    <img src="images/homepage2.jpeg" class="photo" alt="cleaningcrew" width="800" height="400">

    <div class="buttonDiv">
      <!-- motto/slogan -->
      <div class="homepageHeader">Your Clean Home is our Business.</div>
      <br>
      <br>
      <br>
      <!-- buttons with redirect to relevant pages -->
      <button class="btn btn-primary" onclick="window.location.href='https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/Login.php';" type="submit" name="LU" value="activate">LOGIN FOR USER</button>
      <button class="btn btn-success" onclick="window.location.href='https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/register.php';" type="submit" name="RU" value="activate">REGISTER FOR USER</button>
      <button class="btn btn-primary" onclick="window.location.href='https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/Loginemp.php';" type="submit" name="LE" value="activate">LOGIN FOR EMPLOYEE</button>
      <button class="btn btn-success" onclick="window.location.href='https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/employeeRegister.php';" type="submit" name="RE" value="activate">REGISTER FOR EMPLOYEE</button>
      <br>
      <br>
      <br>
      <!-- motto/slogan -->
      <div class="line11">At Domestic Helper, we aim to provide services in order to keep your home clean, we believe a clean home equates to happy life. Just book and leave the rest to us ! </div>
    </div>


    <!-- footer navbar -->
    <div class="topnav" id="bottomnav">

      <p class="footertext" style="color:white">Website created by Sam, Tope & Saahil</p>
    </div>

</body>