<?php
session_start();


include 'Navbars.php';

?>

<!DOCTYPE html>
<head>
<style>
img{
    width: 100%;
    height: auto;
}
h1 {
    text-align: center;
} 
p {
    text-align: center;
}
p.solid {border-style: solid;
         border-color: #555; 
         }

body {background: url(https://wallpaperaccess.com/full/3898677.jpg);
  background-repeat: no-repeat;
  width: 100%;
  height: 100%;
 }

 .infographic {
    background: url(https://agmbenefitsolutions.com/wp-content/uploads/2015/02/Grey-Gradient-Background.jpg);
    background-repeat: no-repeat;
    border: 2px solid black;
    border-radius: 5px;
    text-align: left;
    margin-left: 30%;
    width: 40%;
    
    column-count: 1;
    
  
  /* width: 40%; */
}

#bottomnav {
  background-color: #333;
  overflow: hidden;
  height: 50px;
  bottom: 0;
  margin-bottom: 0.5px;
  width: 100%;
}
</style>
</head>
<body>
<br>
<h1>What are we about ?</h1>
<br>
<br>
 <div class="infographic">
<img src="images/Cleaningcrew.jpg" class="photo" alt="cleaningcrew" width="800" height="400" >
<br>
<p class="solid">We are a local firm located in Kent, United Kingdom that provides a range of domestic services such as cleaning floors, cleaning dishes, washing clothes, dog walking and many others. We provide services all around Kent, in cities such as;Canterbury, Medway, Maidstone, Gillingham, Dartford, Chatham, Ashford, Rochester, Margate, Gravesend and many others around kent. All the members of staff are trained properly to provide the best quality services with appreciating the health and safety of the services and people around them.
<br>
<br>
<br>
Our mission is to provide these services with the best quality and meeting our customer's needs. All our services are mentioned in this website and bookings are available to be made. We also offer some perks for customers that have been our member for more than five years. So what are you waiting for?..... Get your services booked and sit back and enjoy while we provide you the best kind of quality services.
<br>
For further enquiries, please do not hesitate to contact us on:
<br>
<br>
<br>
Phone number- +44 7547839846
<br>
Email- domestichelp@kent.ac.uk
<br>
<br>
<br>
You can also walk in, to our office located in the address below and book a service
<br>
<br>
Address-xxxxxxxx</p>
</div>

<div class="topnav" id="bottomnav">
<p class="footertext" style="color:white">Website created by Sam, Tope, Saahil & Esther</p>

</div>
</body>

