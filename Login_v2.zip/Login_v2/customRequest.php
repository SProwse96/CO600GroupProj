<?php
session_start();
require_once('setup.php');
include 'adminNavbar.php';

if (!$_SESSION) {
	// do nothing, theres no need to!
	
    echo '<script type="text/javascript">';
    echo 'window.location.href="Login.php";';
    echo '</script>';	
}


if (isset($_POST['submit'])) {

	$conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");

	$servicename = $conn->real_escape_string($_POST['servicename']);
	$location = $conn->real_escape_string($_POST['location']);
	$price = $conn->real_escape_string($_POST['price']);
	$servicedesc = $conn->real_escape_string($_POST['servicedesc']);

	if ($price > 0) {

		$conn->query("INSERT INTO customRequests (servicename, servicedesc, location,price) VALUES ('$servicename', '$servicedesc', '$location', '$price')");

		echo ("<script>alert('Custom Request Sent')</script>");
		echo ("<script>window.location = 'Services.php';</script>");
	} else {
		echo ("<script>alert('Something went wrong, please try again.')</script>");
	}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<style>
		#yeet {
			padding-bottom: 100px;
		}

		#bottomnav {
			background-color: #333;
			overflow: hidden;

			bottom: 0;
			width: 100%;
		}
	</style>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>DomesticHelper</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico" />
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<!--===============================================================================================-->
</head>

<body>

	<div class="limiter">
		<div class="container-login100" id="yeet">
			<div class="wrap-login100">
				<form class="login100-form validate-form" method="post">
					<span class="login100-form-title p-b-26">
						New Service
					</span>
					<span class="login100-form-title p-b-48">
						<img src="../logo/DomesticLogo2.png" style="height: 200px; width: 250px">
					</span>

					<div class="wrap-input100 validate-input">
						<p>Service name</p>
						<input class="input100" name="servicename" type="servicename" id="servicename" maxlength="50" required>
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<p>Service description</p>
						<input class="input100" name="servicedesc" type="servicedesc" id="servicedesc" required maxlength="150">
						<span class="focus-input100"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<p>Location</p>
						<input class="input100" name="location" type="location" id="location" maxlength="60" required>
						<span class="focus-input100"></span>
					</div>

					

					<div class="wrap-input100 validate-input">
						<p>Price</p>
						<input class="input100" name="price" type="price" id="price" required>
						<span class="focus-input100"></span>
					</div>

					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" type="submit" name="submit" href="login.php">
								Submit
							</button>
						</div>
					</div>

					<div class="text-center p-t-115">
						<a class="txt2" href="login.php">
							Go back
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>

	<!-- declare our AJAX function, once register button is clicked, confirm entered detials match database -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
	<script type="text/javascript">


	</script>


</body>
<div>
	<p class="footertext" style="color:white" id="bottomnav">Website created by Sam, Tope, Saahil & Esther</p>

</div>

</html>