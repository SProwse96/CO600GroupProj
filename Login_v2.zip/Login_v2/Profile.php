<?php
session_start();



if($_SESSION['email'] == "Admin@Admin.com"){
    // do nothing, theres no need to!
    include 'adminNavbar.php';


}
else if($_SESSION['email']){
    // do nothing, theres no need to!
    include 'LoggedInNavbars.php';
   
}
else{
    header('Location: Login.php'); //redirect back to login.php so users can access any info
    }
    if (isset($_POST['submit'])){

        $bookingID = $_POST['testval'];
        $servicename =$_POST['testval2'];
        $time = $_POST['testval3'];
        $date = $_POST['testval4'];

        $conn = new mysqli ("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");
        $sql = $conn->query("SELECT BookingID, Time, Date FROM Bookings WHERE Time = '$time' AND Date = '$date' AND BookingID = '$bookingID'");

        if($sql->num_rows > 0){
			echo("<script>alert('Booking Deleted')</script>");
            $conn -> query("DELETE FROM Bookings WHERE Time = '$time' AND Date = '$date' AND BookingID = '$bookingID'");
           
		}
        else{
            //do nothing
        }

    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>DomesticHelper</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
      <style>
          h4, h5{
              text-align: center;
          }

          body {
                    text-align: center;
                    background: url(https://wallpaperaccess.com/full/3898677.jpg);
                    background-repeat: no-repeat;
                    background-size: 1920px 1080px;
                    }
                    table, th, td {
                    border: 1px solid black;
                    
                    }
                    .tablecenter{
                        margin-left: auto;
                        margin-right: auto;
                    }

                    #customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 50%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}
#customers tr:nth-child(ODD){background-color: #DDD;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: center;
  background-color: #04AA6D;
  color: white;
}

/* css button styles, credit to HTML Goodies - code found here : https://www.htmlgoodies.com/css/css-button-styles/ */


.viewButton {
display: inline-block;
background-color: #FF0000;
border-radius: 10px;
border: 3px double #FF0000;
color: white;
text-align: center;
font-size: 13px;
padding: 20px;
height: 20px;
width: 100px;
transition: all 0.5s;
cursor: pointer;
margin: 5px;
}
.viewButton input {
cursor: pointer;
display: inline-block;
position: relative;
transition: 0.5s;
}
.viewButton input:after {
content: '0bb';
position: absolute;
opacity: 0;
top: 0;
right: -20px;
transition: 0.5s;
}
.viewButton:hover {
background-color: #FF0000;
color: black;
}
.viewButton:hover input {
padding-right: 25px;

}
.viewButtonhover input:after {
opacity: 1;
right: 0;
}


                
  

            </style>
          </style>
          <body>
            <h4>Profile page for user: <?php echo $_SESSION['email'];  ?></h4> 
            <br>
           <h5>Services Availability</h5>

           
                <br>
                <table class="tablecenter" id="customers">
                    <thead>
                        <tr>
                            <div class="ting"></div>
                            
                            
                            <th>bookingID</th>
                            <th>servicename</th>
                            <th>servicedesc</th>
                            <th>Date </th>
                            <th>Time </th>
                            <th>Book</th>
                            
                        </tr>
                    </thead>

                  
                        <?php
                        ?>


                        
                        <?php
                        $conn = new mysqli ("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");
                        $id = $_SESSION['id'];
                        
                        if($conn->connect_error){
                            die("Connection error: " . $conn->connection_error);
                        }
                        
                        
                        $query="SELECT BookingID, servicename, servicedesc, Date, Time, ServiceID FROM Bookings WHERE id = '$id' ";    
                        $res=$conn->query($query);
                        
                        

                             while($row=$res->fetch_assoc()){

                                echo "<tr>";
                              
                                echo "<td>" . $row['BookingID'] . " " ."</td>";
                              
                                echo "<td>" . $row['servicename'] . " " . "</td>";
                                echo "<td>" . $row['servicedesc'] . " " . "</td>";
                              
                                echo "<td>" . $row['Date'] . " " . "</td>";
                                echo "<td>" . $row['Time'] . " " . "</td>";
                                
                                echo "<td><form method=post>
                                 <input name=testval type=hidden value='".$row['BookingID']."'>
                                 <input name=testval2 type=hidden value='".$row['servicename']."'>
                                 <input name=testval3 type=hidden value='".$row['Time']."'>
                                 <input name=testval4 type=hidden value='".$row['Date']."'>
                                
                                 
                                 <input type=submit name=submit class=viewButton value=Delete></form></td>";
                                echo "</tr>";
                              
                                
                                }
                            
                            
                            $conn->close();
                             ?>
                             
                                   
                    </table>

          </body>