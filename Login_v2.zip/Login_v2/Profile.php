<?php
session_start();

require_once("setup.php");
include 'sessionTime.php';
if ($_SESSION['email'] == "Admin@Admin.com") {
    // do nothing, theres no need to!
    include 'adminNavbar.php';
} else if ($_SESSION['email']) {
    // do nothing, theres no need to!
    include 'LoggedInNavbars.php';
} else {
    header('Location: Login.php'); //redirect back to login.php so users can access any info
}
$conn = mysqli_connect("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20") or die("something went wrong, please try again!");


?>




<?php
if (isset($_SESSION['servicename'])) {
    unset($_SESSION['servicename'], $_SESSION['servicedesc'], $_SESSION['location'], $_SESSION['rating'], $_SESSION['price'], $_SESSION['employeename']);
}
if (isset($_POST['submit2'])) {


    $customID = $_POST['CustomID'];
    $bookingID = $_POST['BookingID'];
    $servicename = $_POST['servicename'];
    $servicedesc = $_POST['servicedesc'];
    $location = $_POST['location'];
    $time = $_POST['Time'];
    $date = $_POST['Date'];
    $endtime = $_POST['Endtime'];
    $acceptedBy = $_POST['acceptedBy'];

    $stmt = $conn->prepare("SELECT BookingID, CustomID FROM activeBookings WHERE BookingID = ? OR CustomID = ?");

    if ($stmt) {
        $stmt->bind_param("ii", $bookingID, $customID);
        $stmt->execute();
        $stmt->bind_result($bookingID, $customID);
        $stmt->store_result();
        $stmt->fetch();
        $count = $stmt->num_rows;

        if ($count > 0) {
            $stmt = $conn->prepare("DELETE FROM activeBookings WHERE (BookingID = ?) OR (CustomID = ?)");
            $stmt->bind_param("ii", $bookingID, $customID);
            $stmt->execute();
            $stmt->close();

?>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Booking Deleted',
                    showConfirmButton: false,
                    timer: 2000
                });
            </script>
        <?php
        } else {
        ?>
            <script>
                Swal.fire({
                    icon: 'Error.',
                    title: 'Something went wrong.',
                    showConfirmButton: false,
                    timer: 2000
                });
            </script>
        <?php
        }
    }
} else if (isset($_POST['submit'])) {



    $bookingID = $_POST['BookingID'];
    $servicename = $_POST['servicename'];
    $servicedesc = $_POST['servicedesc'];
    $location = $_POST['location'];
    $time = $_POST['Time'];
    $date = $_POST['Date'];
    $endtime = $_POST['Endtime'];
    $acceptedBy = $_POST['acceptedBy'];

    $stmt = $conn->prepare("SELECT BookingID, Time, Date FROM Bookings WHERE BookingID = ? AND Time = ? AND Date = ?  ");

    if ($stmt) {
        $stmt->bind_param("iss", $bookingID, $time, $date);
        $stmt->execute();
        $stmt->bind_result($bookingID, $time, $date);
        $stmt->store_result();
        $stmt->fetch();
        $count = $stmt->num_rows;

        if ($count > 0) {

            $stmt = $conn->prepare("DELETE FROM Bookings WHERE BookingID = ?");
            $stmt->bind_param("i", $bookingID);
            $stmt->execute();
            $stmt->close();

        ?>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Booking Deleted.',
                    showConfirmButton: false,
                    timer: 2000
                });
            </script>

        <?php
        }
    } else {
        ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Something went wrong.',
                showConfirmButton: false,
                timer: 2000
            });
        </script>

        <?php
    }
} else if (isset($_POST['submit3'])) {


    $customID = $_POST['customID'];
    $requestedByUser = $_POST['requestedByUser'];
    $servicename = $_POST['servicename'];
    $servicedesc = $_POST['servicedesc'];
    $location = $_POST['location'];
    $time = $_POST['Time'];
    $date = $_POST['Date'];
    $endtime = $_POST['Endtime'];
    $price = $_POST['price'];


    $stmt = $conn->prepare("SELECT CustomID, Time, Date, requestedByUser FROM customRequests WHERE CustomID = ? AND Time = ? AND Date = ? AND requestedByUser = ?");

    if ($stmt) {
        $stmt->bind_param("issi", $customID, $time, $date, $requestedByUser);
        $stmt->execute();
        $stmt->bind_result($customID, $time, $date, $requestedByUser);
        $stmt->store_result();
        $stmt->fetch();
        $count = $stmt->num_rows;
        if ($count > 0) {
            $stmt = $conn->prepare("DELETE FROM customRequests WHERE CustomID = ?");
            $stmt->bind_param("i", $customID);
            $stmt->execute();
            $stmt->close();

        ?>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Custom Request Deleted.',
                    showConfirmButton: false,
                    timer: 2000
                });
            </script>
        <?php
        } else {
        ?>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Custom Request Delete failed, please try again.',
                    showConfirmButton: false,
                    timer: 2000
                });
            </script>
        <?php
        }
    } else {
        ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Something went wrong, please try again later.',
                showConfirmButton: false,
                timer: 2000
            });
        </script>
    <?php
    }
} else if (isset($_POST['submit4'])) {


    $customID = $_POST['customID'];
    $requestedByUser = $_POST['requestedByUser'];
    $servicename = $_POST['servicename'];
    $servicedesc = $_POST['servicedesc'];
    $location = $_POST['location'];
    $time = $_POST['Time'];
    $date = $_POST['Date'];
    $endtime = $_POST['Endtime'];
    $price = $_POST['price'];


    $stmt = $conn->prepare("SELECT BookingID, Time, Date, requestedByUser FROM completedBookings WHERE bookingID = ? AND Time = ? AND Date = ? AND requestedByUser = ?");
    $stmt->bind_param("issi", $bookingID, $time, $date, $requestedByUser);
    $stmt->execute();
    $stmt->bind_result($bookingID, $time, $date, $requestedByUser);
    $stmt->store_result();
    $stmt->fetch();
    $count = $stmt->num_rows;

    //$sql = $conn->query("SELECT CustomID, Time, Date FROM customRequests WHERE Time = '$time' AND Date = '$date' AND requestedByUser = '$requestedByUser'");

    if ($count > 0) {
        //do nothing, show the leave review page.
    } else {

    ?>
        <script>
            Swal.fire({
                icon: 'Error.',
                title: 'Something went wrong.',
                showConfirmButton: false,
                timer: 2000
            });
        </script>
    <?php
    }
} else if (isset($_POST['viewReview'])) {


    $customID = $_POST['customID'];
    $requestedByUser = $_POST['requestedByUser'];
    $servicename = $_POST['servicename'];
    $servicedesc = $_POST['servicedesc'];
    $location = $_POST['location'];
    $time = $_POST['Time'];
    $date = $_POST['Date'];
    $endtime = $_POST['Endtime'];
    $price = $_POST['price'];
    $bookingID = $_POST['BookingID'];

    $sql = $conn->query("SELECT CustomID, Time, Date FROM customRequests WHERE Time = '$time' AND Date = '$date' AND requestedByUser = '$requestedByUser'");

    if ($sql->num_rows > 0) {
        //do nothing, show the leave review page.
    } else {

    ?>
        <script>
            Swal.fire({
                icon: 'Error.',
                title: 'Something went wrong.',
                showConfirmButton: false,
                timer: 2000
            });
        </script>
<?php
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>DomesticHelper</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="images/icons/favicon.ico" />
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!--===============================================================================================-->
    <style>
        h4,
        h5 {
            text-align: center;
        }

        body {
            text-align: center;
            background: url(https://wallpaperaccess.com/full/3898677.jpg);
            background-repeat: no-repeat;
            background-size: 1920px 1080px;
        }

        table,
        th,
        td {
            border: 1px solid black;

        }

        .tablecenter {
            margin-left: auto;
            margin-right: auto;
        }

        #customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 50%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers tr:nth-child(ODD) {
            background-color: #DDD;
        }

        #customers tr:hover {
            background-color: #ddd;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: center;
            background-color: #04AA6D;
            color: white;
        }

        /* css button styles, credit to HTML Goodies - code found here : https://www.htmlgoodies.com/css/css-button-styles/ */


        .viewButton {
            display: inline-block;
            background-color: #3CB371;
            border-radius: 10px;
            color: white;
            text-align: center;
            font-size: 13px;
            padding: 20px;
            height: 20px;
            width: 100px;
            transition: all 0.5s;
            cursor: pointer;
            margin: 5px;
            line-height: 0px;
        }

        .viewButton input {
            cursor: pointer;
            display: inline-block;
            position: relative;
            transition: 0.5s;
        }

        .viewButton input:after {
            content: '0bb';
            position: absolute;
            opacity: 0;
            top: 0;
            right: -20px;
            transition: 0.5s;
        }

        .viewButton:hover {
            background-color: white;
            color: black;
        }

        .viewButton:hover input {
            padding-right: 25px;

        }

        .viewButtonhover input:after {
            opacity: 1;
            right: 0;
        }

        .what {
            text-align: center;
        }

        #showReview,
        #leaveReview {
            padding: 0px;
            width: 100px;
            height: 50px;
        }

        #leaveReview {
            background-color: #ffa500;
        }

        #big4:hover {
            background-color: white;
            color: black;
            transition-duration: 0.5s;
            cursor: pointer;
        }

        #big4:focus {
            background-color: white;
            color: black;
        }
    </style>


<body>
    <br>
    <h4>Profile page for user: <?php echo $_SESSION['email'];  ?></h4>
    <br>

    <a class="btn btn-primary glyphicon glyphicon-search" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample" id="big4">
        <h4>Booking Requests</h4>
        &#8595;

    </a>


    <div class="collapse" id="collapseExample">
        <div class="card-body">
            <table class="tablecenter" id="customers">
                <thead>
                    <tr>
                        <div class="ting"></div>


                        <th>Booking ID</th>
                        <th>Service Name</th>
                        <th>Service Description</th>
                        <th>Location</th>
                        <th>Date</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Accepted By</th>
                        <th>Cancel</th>

                    </tr>
                </thead>

                <?php
                $conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");
                $id = $_SESSION['id'];

                if ($conn->connect_error) {
                    die("Connection error: " . $conn->connection_error);
                }


                $query = "SELECT BookingID, servicename, servicedesc, location, Date, Time, endtime, acceptedBy, ServiceID FROM Bookings WHERE id = '$id' ";
                $res = $conn->query($query);



                while ($row = $res->fetch_assoc()) {

                    echo "<tr>";

                    echo "<td>" . $row['BookingID'] . " " . "</td>";

                    echo "<td>" . $row['servicename'] . " " . "</td>";
                    echo "<td>" . $row['servicedesc'] . " " . "</td>";
                    echo "<td>" . $row['location'] . " " . "</td>";

                    echo "<td>" . $row['Date'] . " " . "</td>";
                    echo "<td>" . $row['Time'] . " " . "</td>";
                    echo "<td>" . $row['endtime'] . " " . "</td>";
                    echo "<td>" . $row['acceptedBy'] . " " . "</td>";
                    echo "<td><form method=post>
                                 <input name=BookingID type=hidden value='" . $row['BookingID'] . "'>
                                 <input name=servicename type=hidden value='" . $row['servicename'] . "'>
                                 <input name=servicedesc type=hidden value='" . $row['servicedesc'] . "'>
                                 <input name=location type=hidden value='" . $row['location'] . "'>

                                 <input name=Time type=hidden value='" . $row['Time'] . "'>
                                 <input name=Endtime type=hidden value='" . $row['endtime'] . "'>
                                 <input name=Date type=hidden value='" . $row['Date'] . "'>
                                 <input name=acceptedBy type=hidden value='" . $row['acceptedBy'] . "'>
                                 <input type=submit name=submit class=viewButton value=Delete></form></td>";
                    echo "</tr>";
                }


                $conn->close();
                ?>


            </table>
        </div>
    </div>


    <a class="btn btn-primary glyphicon glyphicon-search" data-toggle="collapse" href="#collapseExample2" role="button" aria-expanded="false" aria-controls="collapseExample" id="big4">
        <h4>Ongoing Jobs</h4>
        &#8595;

    </a>

    <div class="collapse" id="collapseExample2">
        <div class="card-body">



            <table class="tablecenter" id="customers">

                <thead>
                    <tr>
                        <div class="ting"></div>

                        <th>Custom ID</th>
                        <th>Booking ID</th>
                        <th>Service Name</th>
                        <th>Service Description</th>
                        <th>Location</th>
                        <th>Date</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Accepted By</th>
                        <th>Cancel</th>

                    </tr>
                </thead>

                <?php
                $conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");
                $id = $_SESSION['id'];

                if ($conn->connect_error) {
                    die("Connection error: " . $conn->connection_error);
                }


                $query = "SELECT * FROM activeBookings WHERE id = '$id' ";
                $res = $conn->query($query);



                while ($row = $res->fetch_assoc()) {

                    echo "<tr>";
                    echo "<td>" . $row['CustomID'] . " " . "</td>";
                    echo "<td>" . $row['BookingID'] . " " . "</td>";

                    echo "<td>" . $row['servicename'] . " " . "</td>";
                    echo "<td>" . $row['servicedesc'] . " " . "</td>";

                    echo "<td>" . $row['location'] . " " . "</td>";
                    echo "<td >" . $row['Date'] . " " . "</td>";
                    echo "<td>" . $row['Time'] . " " . "</td>";
                    echo "<td>" . $row['endtime'] . " " . "</td>";
                    echo "<td>" . $row['acceptedBy'] . " " . "</td>";

                    echo "<td><form method=post>
                                <input name=CustomID type=hidden value='" . $row['CustomID'] . "'>
                                 <input name=BookingID type=hidden value='" . $row['BookingID'] . "'>
                                 <input name=servicename type=hidden value='" . $row['servicename'] . "'>
                                 <input name=servicedesc type=hidden value='" . $row['servicedesc'] . "'>
                                 <input name=Time type=hidden value='" . $row['Time'] . "'>
                                 <input name=Endtime type=hidden value='" . $row['endtime'] . "'>
                                 <input name=Date type=hidden value='" . $row['Date'] . "'>
                                 <input name=acceptedBy type=hidden value='" . $row['acceptedBy'] . "'>
                                 <input name=location type=hidden value='" . $row['location'] . "'>
                                 
                                 <input type=submit name=submit2 class=viewButton value=Delete></form></td>";
                    echo "</tr>";
                }


                $conn->close();
                ?>

            </table>
        </div>
    </div>



    <a class="btn btn-primary glyphicon glyphicon-search" data-toggle="collapse" href="#collapseExample3" role="button" aria-expanded="false" aria-controls="collapseExample" id="big4">
        <h4>Custom Requests</h4>
        &#8595;

    </a>

    <div class="collapse" id="collapseExample3">
        <div class="card-body">
            <table class="tablecenter" id="customers">

                <thead>
                    <tr>
                        <div class="ting"></div>

                        <th>Custom ID</th>
                        <th>User ID</th>
                        <th>Service Name</th>
                        <th>Service Description</th>
                        <th>Location</th>
                        <th>Date</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Price</th>
                        <th>Cancel</th>

                    </tr>
                </thead>

                <?php
                $conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");
                $id = $_SESSION['id'];

                if ($conn->connect_error) {
                    die("Connection error: " . $conn->connection_error);
                }


                $query = "SELECT * FROM customRequests WHERE requestedByUser = '$id' ";
                $res = $conn->query($query);



                while ($row = $res->fetch_assoc()) {

                    echo "<tr>";
                    echo "<td>" . $row['CustomID'] . " " . "</td>";
                    echo "<td>" . $row['requestedByUser'] . " " . "</td>";

                    echo "<td>" . $row['servicename'] . " " . "</td>";
                    echo "<td>" . $row['servicedesc'] . " " . "</td>";
                    echo "<td>" . $row['location'] . " " . "</td>";
                    echo "<td >" . $row['Date'] . " " . "</td>";
                    echo "<td>" . $row['Time'] . " " . "</td>";
                    echo "<td>" . $row['endtime'] . " " . "</td>";
                    echo "<td>" . $row['price'] . " " . "</td>";

                    echo "<td><form method=post>
                             <input name=customID type=hidden value='" . $row['CustomID'] . "'>
                             <input name=requestedByUser type=hidden value='" . $row['requestedByUser'] . "'>
                             <input name=servicename type=hidden value='" . $row['servicename'] . "'>
                             <input name=servicedesc type=hidden value='" . $row['servicedesc'] . "'>
                             <input name=Time type=hidden value='" . $row['Time'] . "'>
                             <input name=Endtime type=hidden value='" . $row['endtime'] . "'>
                             <input name=Date type=hidden value='" . $row['Date'] . "'>
                             <input name=price type=hidden value='" . $row['price'] . "'>
                             <input name=location type=hidden value='" . $row['location'] . "'>
                             <input type=submit name=submit3 class=viewButton value=Delete></form></td>";
                    echo "</tr>";
                }

                $conn->close();
                ?>

            </table>
        </div>
    </div>



    <a class="btn btn-primary glyphicon glyphicon-search" data-toggle="collapse" href="#collapseExample4" role="button" aria-expanded="false" aria-controls="collapseExample" id="big4">
        <h4>Completed Bookings</h4>
        &#8595;

    </a>

    <div class="collapse" id="collapseExample4">
        <div class="card-body">


            <table class="tablecenter" id="customers">

                <thead>
                    <tr>
                        <div class="ting"></div>



                        <th>Service Name</th>
                        <th>Service Description</th>
                        <th>Location</th>
                        <th>Date</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Completed By</th>
                        <th>Review</th>



                    </tr>
                </thead>

                <?php
                $conn = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");
                $id = $_SESSION['id'];

                if ($conn->connect_error) {
                    die("Connection error: " . $conn->connection_error);
                }


                $query = "SELECT * FROM completedBookings WHERE id = '$id' ";
                $res = $conn->query($query);



                while ($row = $res->fetch_assoc()) {

                    echo "<tr>";

                    echo "<td>" . $row['servicename'] . " " . "</td>";
                    echo "<td>" . $row['servicedesc'] . " " . "</td>";
                    echo "<td>" . $row['location'] . " " . "</td>";
                    echo "<td>" . $row['Date'] . " " . "</td>";
                    echo "<td>" . $row['Time'] . " " . "</td>";
                    echo "<td>" . $row['endtime'] . " " . "</td>";
                    echo "<td>" . $row['acceptedBy'] . " " . "</td>";

                    if (($row['LeftReview']) == 'No') {
                        echo "<td><form action=reviewService.php method=post>";
                    } else {
                        echo "<td><form action=showReview.php method=post>";
                    }


                    echo        "<input name=servicename type=hidden value='" . $row['servicename'] . "'>";
                    echo        "<input name=BookingID type=hidden value='" . $row['BookingID'] . "'>";
                    echo        "<input name=ServiceID type=hidden value='" . $row['ServiceID'] . "'>";
                    echo        "<input name=EmpID type=hidden value='" . $row['EmpID'] . "'>";
                    echo        "<input name=servicedesc type=hidden value='" . $row['servicedesc'] . "'>";
                    echo        "<input name=Time type=hidden value='" . $row['Time'] . "'>";
                    echo        "<input name=Endtime type=hidden value='" . $row['endtime'] . "'>";
                    echo        "<input name=Date type=hidden value='" . $row['Date'] . "'>";
                    echo        "<input name=location type=hidden value='" . $row['location'] . "'>";
                    echo        "<input name=acceptedBy type=hidden value='" . $row['acceptedBy'] . "'>";


                    // create if statement here, if a review already exists, insert a 'show review' button, otherwise, 'leave review button'
                    if (($row['LeftReview']) == 'No') {
                        echo "<input type=submit name=submit4 class=viewButton id=leaveReview value='leave review'>";
                    } else {
                        echo "<input type=submit name=viewReview class=viewButton id=showReview value='show review'>";
                    }

                    echo "</form></td>";
                    echo "</tr>";
                }
                $conn->close();
                ?>

            </table>
        </div>
    </div>
</body>