<!-- Credit for template use ; Login Form V2 by Colorlib, free template, see here https://colorlib.com/wp/template/login-form-v2/ -->
<!-- Credit for responsive navbar: How to create a responsive top navigation bar by W3Schools, source is here : https://www.w3schools.com/howto/howto_js_topnav_responsive.asp -->

<?php
session_start();

$phoneno = $_SESSION['phoneno'];
$fname =  $_SESSION['fname'];
$sname =  $_SESSION['sname'];
include 'Navbars.php';
require_once("setup.php");


$conn = mysqli_connect("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20") or die("something went wrong, please try again!");


if (isset($_SESSION['servicename'])) {
	unset($_SESSION['servicename'], $_SESSION['servicedesc'], $_SESSION['location'], $_SESSION['rating'], $_SESSION['price'], $_SESSION['employeename']);
}

if (isset($_POST['submit'])) {

	$password    = $_POST['password'];
	$confirmpass = $_POST['confirmpass'];
	$phoneno = $_SESSION['phoneno'];

	// hashed password to be stored in the database.
	$hash = password_hash($password, PASSWORD_BCRYPT);

	$stmt = $conn->prepare("SELECT fname, sname, phoneno FROM employee WHERE phoneno = ?");
	$stmt->bind_param("s", $phoneno);
	$stmt->execute();
	$stmt->bind_result($fname, $sname, $phoneno);
	$stmt->store_result();
	$stmt->fetch();
	$count = $stmt->num_rows;

	$stmt2 = $conn->prepare("SELECT fname, sname, phoneno FROM users WHERE phoneno = ?");
	$stmt2->bind_param("s", $phoneno);
	$stmt2->execute();
	$stmt2->bind_result($fname, $sname, $phoneno);
	$stmt2->store_result();
	$stmt2->fetch();
	$count2 = $stmt2->num_rows;



	if ($count > 0 and $password == $confirmpass) {
		$stmt = $conn->prepare("UPDATE employee SET password = ? WHERE phoneno = ?");
		$stmt->bind_param("ss", $hash, $phoneno);
		$stmt->execute();
		$stmt->close();

?>

		<script>
			Swal.fire({
				icon: 'success',
				title: 'Sucessful',
				text: 'employee password successfully changed.',

			}).then(function() {
				window.location = "https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/login.php";
			});
		</script>
	<?php
		session_unset();
	} else if ($count2 > 0 and $password == $confirmpass) {
		$stmt2 = $conn->prepare("UPDATE users SET password = ? WHERE phoneno = ?");
		$stmt2->bind_param("ss", $hash, $phoneno);
		$stmt2->execute();
		$stmt2->close();

?>

		<script>
			Swal.fire({
				icon: 'success',
				title: 'Sucessful',
				text: 'user password successfully changed.',

			}).then(function() {
				window.location = "https://raptor.kent.ac.uk/proj/comp6000/project/20/Login_v2/loginEmp.php";
			});
		</script>
	<?php
		session_unset();
	} else {

	?>

		<script>
			Swal.fire({
				icon: 'error',
				title: 'Error',
				text: 'passwords do not match.',

			})
		</script>
<?php
	}
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
	<style>
		#bottomnav {
			background-color: #333;
			overflow: hidden;

			bottom: 0;
			width: 100%;
		}

		.footertext {
			text-align: center;
		}

		.containersubtitle {
			text-align: center;
		}
	</style>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>DomesticHelper - Password Reset</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico" />
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<!--===============================================================================================-->
</head>


<body href="images/loginbackground.jpg">
	<script>
		function func() {
			var password_element = document.getElementById("password");
			if (password_element.type === "password") {
				password_element.type = "text";
			} else {
				password_element.type = "password";
			}
		}
	</script>

	<script>
		function func2() {
			var password_element = document.getElementById("confirmpass");
			if (password_element.type === "password") {
				password_element.type = "text";
			} else {
				password_element.type = "password";
			}
		}
	</script>


	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form" method="post" action="newpass.php">
					<span class="login100-form-title p-b-26">
						Password Reset
					</span>
					<h5 class="containersubtitle">enter new password</h5>
					<br>
					<br>


					<div class="wrap-input100 validate-input" data-validate="Enter password" required>
						<p>Password</p>
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye" onclick="func()"></i>
						</span>
						<input class="input100 form-control input_pass" type="password" name="password" id="password">
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 validate-input" data-validate="Enter password" required>
						<p>Password</p>
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye" onclick="func2()"></i>
						</span>
						<input class="input100 form-control input_pass" type="password" name="confirmpass" id="confirmpass">
						<span class="focus-input100"></span>
					</div>

					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" id="Sign_in" name="submit" type="submit">
								Reset
							</button>
						</div>
					</div>


				</form>
			</div>
		</div>
	</div>
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
	<script>
		function myFunction() {
			var x = document.getElementById("myTopnav");
			if (x.className === "topnav") {
				x.className += " responsive";
			} else {
				x.className = "topnav";
			}
		}
	</script>




</body>

<div>
	<p class="footertext" style="color:white" id="bottomnav">Website created by Sam, Tope, Saahil</p>

</div>

</html>