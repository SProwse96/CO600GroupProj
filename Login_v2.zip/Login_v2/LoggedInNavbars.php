<!-- Credit for responsive navbar: How to create a responsive top navigation bar by W3Schools, source is here : https://www.w3schools.com/howto/howto_js_topnav_responsive.asp -->
<!DOCTYPE html>
<html>

<head>
  <?php echo "<link rel=icon href=../Logo/favicon.ico type=image/x-icon />"; ?>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>

    /* styling of body text */
    body {
      margin: 0;
      font-family: Arial, Helvetica, sans-serif;
    }

   
    /* navbar positioning and colour */
    .topnav {
      overflow: hidden;
      background-color: #333;
    }

    .topnav a {
      float: left;
      display: block;
      color: #f2f2f2;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
      font-size: 17px;
    }

    .topnav a.navBarOptions:hover {
      background-color: #ddd;
      color: black;
    }

    .topnav a.active {
      background-color: #04AA6D;
      color: white;
    }

    .topnav .icon {
      display: none;
    }
    /* add margin to each of the navbar elements */
    #navBarText {
      margin-top: 10px;
    }

    /* footer navbar positioning and colour change */
    #bottomnav {
      background-color: #333;
      overflow: hidden;
      position: fixed;
      bottom: 0;
      width: 100%;
    }

    /* displaying of navbar dependant on browser window size */
    @media screen and (max-width: 600px) {
      .topnav a:not(:first-child) {
        display: none;
      }

      .topnav a.icon {
        float: right;
        display: block;
      }
    }

    @media screen and (max-width: 600px) {
      .topnav.responsive {
        position: relative;
      }

      .topnav.responsive .icon {
        position: absolute;
        right: 0;
        top: 0;
      }

      .topnav.responsive a {
        float: none;
        display: block;
        text-align: left;
      }
    }
    /* align the text of footer */
    .footertext {
      text-align: center;
    }
  </style>
</head>

<body>
<!-- top navbar with relevant links to other pages -->
  <div class="topnav" id="myTopnav">
    <a><img src="../logo/DomesticLogo2.png" alt="Logo" style="height: 50px; width: 75px"> </a>
    <a href="About.php" class="navbarOptions" id="navBarText">About us</a>
    <a href="Guide.php" class="navbarOptions" id="navBarText">Guide</a>
    <a href="Logout.php" class="navbarOptions" id="navBarText">Logout</a>
    <a href="Services.php" class="navbarOptions" id="navBarText">Services</a>
    <a href="Profile.php" class="navbarOptions" id="navBarText">Profile</a>
    <a href="javascript:void(0);" class="icon" onclick="myFunction()">
      <i class="fa fa-bars"></i>
    </a>
  </div>

  <div class="topnav" id="bottomnav">
    <!-- colour change of text in footer navbar -->
    <p class="footertext" style="color:white">Website created by Sam, Tope, Saahil</p>
  </div>

  <script>
    function myFunction() {
      var x = document.getElementById("myTopnav");
      if (x.className === "topnav") {
        x.className += " responsive";
      } else {
        x.className = "topnav";
      }
    }
  </script>

  <div id="dropDownSelect1"></div>
<!-- script files for jQuery -->
  <!--===============================================================================================-->
  <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
  <!--===============================================================================================-->
  <script src="vendor/animsition/js/animsition.min.js"></script>
  <!--===============================================================================================-->
  <script src="vendor/bootstrap/js/popper.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <!--===============================================================================================-->
  <script src="vendor/select2/select2.min.js"></script>
  <!--===============================================================================================-->
  <script src="vendor/daterangepicker/moment.min.js"></script>
  <script src="vendor/daterangepicker/daterangepicker.js"></script>
  <!--===============================================================================================-->
  <script src="vendor/countdowntime/countdowntime.js"></script>
  <!--===============================================================================================-->
  <script src="js/main.js"></script>

</body>

</html>