<?php
session_start();
require_once('setup.php');
include 'adminNavbar.php'; 

if($_SESSION['email'] != "Admin@Admin.com"){
    // do nothing, theres no need to!
    header('Location: Login.php');
    
}


if (isset($_POST['submit'])){
	
	$conn = new mysqli ("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");

	$fname = $conn->real_escape_string($_POST['fname']);
	$sname = $conn->real_escape_string($_POST['sname']);
	$address = $conn->real_escape_string($_POST['address']);
	$phoneno = $conn->real_escape_string($_POST['phoneno']);
	$postcode = $conn->real_escape_string($_POST['postcode']);
	$email = $conn->real_escape_string($_POST['email']);
	$gender = $conn->real_escape_string($_POST['gender']);
	$password = $conn->real_escape_string($_POST['password']);

	$hash = password_hash($password, PASSWORD_BCRYPT);

	$dup = mysqli_query($conn, "SELECT * FROM employee WHERE email = '$email'");

	if(mysqli_num_rows($dup)> 0){
		
	// PHP program to pop an alert
	// message box on the screen
	echo("<script>alert('Email already exists.')</script>");
	// Display the alert box 
	
  	
	}
	if($gender == 'F' or $gender == 'M'){
		
		$conn ->query("INSERT INTO employee (fname,sname,address,phoneno,postcode,email,gender,password) VALUES ('$fname', '$sname', '$address', '$phoneno', '$postcode', '$email', '$gender', '$hash')");
		echo("<script>alert('Employee added.')</script>");
 		echo("<script>window.location = 'Services.php';</script>");	
	}
	else{
		echo("<script>alert('Wrong Gender, registration failed.')</script>");
}

	
	
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<title>DomesticHelper</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>

<body>

<script>

	//function to show password or not on register page.
function func(){
	var password_element = document.getElementById("password");
	if(password_element.type === "password"){
		password_element.type = "text";
	} else{
		password_element.type = "password";
	}
}

</script>

<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form" method="post">
					<span class="login100-form-title p-b-26">
						New Employee Register
					</span>
					<span class="login100-form-title p-b-48">
					<img src="../logo/DomesticLogo2.png" style="height: 200px; width: 250px">
					</span>

                    <div class="wrap-input100 validate-input">
						<input class="input100" name="fname" type="fname" id="fname" required>
						<span class="focus-input100" data-placeholder="First Name"></span>
					</div>

                    <div class="wrap-input100 validate-input">
						<input class="input100" name="sname" type="sname" id="sname" required>
						<span class="focus-input100" data-placeholder="Last Name"></span>
					</div>

                    <div class="wrap-input100 validate-input">
						<input class="input100" name="address" type="address" id="address" required>
						<span class="focus-input100" data-placeholder="Address"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<input class="input100" name="phoneno" type="phoneno" id="phoneno" required>
						<span class="focus-input100" data-placeholder="Phone Number"></span>
					</div>

                    <div class="wrap-input100 validate-input">
						<input class="input100" name="postcode" type="postcode" id="postcode" required>
						<span class="focus-input100" data-placeholder="Post Code"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate = "Valid email is: please use correct email format, eg: johndoe@example.com">
						<input class="input100" name="email" type="email" id="email" required>
						<span class="focus-input100" data-placeholder="Email"></span>
					</div>

					<div class="wrap-input100 validate-input">
						<input class="input100" name="gender" type="gender" id="gender" required maxlength="1" data-validate="please enter M for Male or F for Female">
						<span class="focus-input100" data-placeholder="Gender"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password" required>
						<span class="btn-show-pass">
							<i class="zmdi zmdi-eye" onclick="func()"></i>
						</span>
						<input class="input100 form-control input_pass" type="password" name="password" id="password">
						<span class="focus-input100" data-placeholder="Password"></span>
					</div>

					

					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" type="submit" name="submit" href="login.php" >
								Sign up
							</button>
						</div>
					</div>

					<div class="text-center p-t-115">
						<a class="txt2" href="login.php">
							Go back
						</a>
					</div>
				</form>
			</div>
		</div>
	</div>

    <!-- declare our AJAX function, once register button is clicked, confirm entered detials match database -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>
<script type="text/javascript">
	
	
</script>


</body>
</html>