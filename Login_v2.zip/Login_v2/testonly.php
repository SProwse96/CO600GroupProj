<!DOCTYPE html>
<html>

<head>
    <title>PHP HTML TABLE DATA SEARCH</title>
    <style>
        table,
        tr,
        th,
        td {
            border: 1px solid black;
        }
    </style>
</head>

<body>

<?php

if (isset($_POST['search'])) {
    $valueToSearch = $_POST['valueToSearch'];
    // search in all table columns
    // using concat mysql function
    $query = "SELECT * FROM `Service` WHERE servicename LIKE '%" . $valueToSearch . "%'";
    $search_result = filterTable($query);
} else {
    $query = "SELECT * FROM `Service`";
    $search_result = filterTable($query);
}

// function to connect and execute the query
function filterTable($query)
{
    $connect = new mysqli("dragon.kent.ac.uk", "comp6000_20", "wrochs6", "comp6000_20");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

    <form action="<?=$_SERVER['PHP_SELF']?>"  method="post">
        <input type="text" name="valueToSearch" placeholder="Value To Search"><br><br>
        <input type="submit" name="search" value="Filtrar"><br><br>

        <table border="2">
            <tr>
                <td>ID</td>
                <td>Cédula</td>
                <td>Nombre</td>
                <td>Apellido</td>
                <td>Género</td>
                <td>Año de Nacimiento</td>
                <td>Correo</td>
                <td>Desde</td>
                <td>Edit</td>
                <td>Delete</td>
            </tr>

            <!-- populate table from mysql database -->
            <?php
            while ($row = $search_result->fetch_assoc()) : ?>
                <tr>
                    <td><?php echo $row['servicename'] ?></td>
                    <td><?php echo $row['servicedesc'] ?></td>
                    <td><?php echo $row['location'] ?></td>
                    <td><?php echo $row['price'] ?></td>
                    <td><?php echo $row['rating'] ?></td>
                    <td><a href="/db/db_mod.php?id=<?php echo $row['user_id']; ?>">Edit</a></td>
                    <td><a href="/db/db_del.php?id=<?php echo $row['user_id']; ?>">Delete</a></td>
                </tr>
            <?php endwhile; ?>
        </table>
    </form>

</body>

</html>


</body>

</html>