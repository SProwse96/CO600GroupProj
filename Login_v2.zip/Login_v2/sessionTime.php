<?php
require_once("setup.php");

if(isset($_SESSION['id']) OR ($_SESSION['EmpID'])) {
?>
	<script>
		setTimeout(function() {
			window.location = 'Logout.php';
		}, 300000); //redirect after 5 mins of inactivity, will destroy the session and update the value of isLoggedIn in the database
	</script>
<?php
}




