<?php
require_once("setup.php");
$expiry = 600 ;//session expiry required after 10 minutes
if (isset($_SESSION['sessionTime']) && (time() - $_SESSION['sessionTime'] > $expiry)) {
    
    $logoutvalue = 0;
                    $stmt = $conn->prepare("UPDATE users SET isLoggedIn = ? WHERE email = ?");
					$stmt->bind_param("is", $logoutvalue, $_SESSION["email"]);
					$stmt->execute();
					$stmt->close();

                    $stmt2 = $conn->prepare("UPDATE employee SET isLoggedIn = ? WHERE email = ?");
					$stmt2->bind_param("is", $logoutvalue, $_SESSION["email"]);
					$stmt2->execute();
					$stmt2->close();


    session_unset();
    session_destroy();
}

?>