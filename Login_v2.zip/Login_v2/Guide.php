<!-- Session done from tutorial video: source to video is: https://www.youtube.com/watch?v=vESwDXV81F0 -->
<!-- Credit for responsive navbar: How to create a responsive top navigation bar by W3Schools, source is here : https://www.w3schools.com/howto/howto_js_topnav_responsive.asp -->
<!-- initialise session variable, linked to Login.php -->
<?php
session_start();
include 'Navbars.php';
?>

<!DOCTYPE HTML>
<html>
<head>
    <style>
p {
    text-align: center;
}
h1{
    text-align: center;
}

.infographic {
    background: url(https://agmbenefitsolutions.com/wp-content/uploads/2015/02/Grey-Gradient-Background.jpg);
    background-repeat: no-repeat;
    border: 2px solid black;
    border-radius: 5px;
    text-align: left;
    margin-left: 30%;
    width: 40%;
    
    column-count: 1;
    
  
  /* width: 40%; */
}
.bodyText {
    text-align: left;
    margin-left: 2px;
}


body {
  background: url(https://wallpaperaccess.com/full/3898677.jpg);
  background-repeat: no-repeat;
  background-size: 1920px 1080px;
}
img{
    width: 100%;
    height: auto;
}

#bottomnav {
  background-color: #333;
  overflow: hidden;
  height: 50px;
  position: fixed;
  bottom:0;
  
  width: 100%;
}

    </style>
<body>

    <h1> Welcome to the guide page</h1>
    <p >Follow the instructions below for more information on how to get started.</p>
    
    <div class="infographic">
        
    <img src="images/CleaningPhoto.png" class="photo" alt="cleaningphoto" width="700" height="500" >
    
    <br>
    
    <p >Follow the instructions below for more information on how to get started.</p>  
     <p class="bodyText">1. Head over to the services tab via 'Services' at the top of your screen</p>
     <p class="bodyText">2. Browse the service selection for the service you require, use the filers if needed.</p>
     <p class="bodyText">3. Once an ideal service is found, click the service and enter details to make a booking</p>
     <p class="bodyText">4. If you can't find a service please contact us via the contact form and we can see what we can do for you.</p>
     <p class="bodyText">5. Done!</p>
</div>


</body>
<div class="topnav" id="bottomnav">
<p class="footertext" style="color:white">Website created by Sam, Tope, Saahil & Esther</p>

</div>
</head>

</html>