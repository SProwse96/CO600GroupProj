<!-- Session done from tutorial video: source to video is: https://www.youtube.com/watch?v=vESwDXV81F0 -->
<!-- Credit for responsive navbar: How to create a responsive top navigation bar by W3Schools, source is here : https://www.w3schools.com/howto/howto_js_topnav_responsive.asp -->
<!-- initialise session variable, linked to Login.php -->
<?php
//start the session
session_start();
//include navbar for website navigation
include 'Navbars.php';
?>

<!DOCTYPE HTML>
<html>

<head>
    <style>
        /*styling of parahraph and h1 elements, center their text */
        p {
            text-align: center;
        }

        h1 {
            text-align: center;
        }

        /*styling of our element where our guide details are */
        .infographic {
            background: url(https://agmbenefitsolutions.com/wp-content/uploads/2015/02/Grey-Gradient-Background.jpg);
            background-repeat: no-repeat;
            border: 2px solid black;
            border-radius: 5px;
            text-align: left;
            margin-left: 30%;
            width: 40%;
            column-count: 1;
        }

        /* aligning our text that is within the infograhpic */
        .bodyText {
            text-align: left;
            margin-left: 2px;
        }

        /* styling our body using an image, dont repeat the image multiple times either */
        body {
            background: url(https://wallpaperaccess.com/full/3898677.jpg);
            background-repeat: no-repeat;
            background-size: 1920px 1080px;
            /* resolution */
        }

        /* make the image fit 100% the width of the infographic, but make height auto so it don't overlap other elements */
        img {
            width: 100%;
            height: auto;
        }

        /* bottom navbar styling */
        #bottomnav {
            background-color: #333;
            overflow: hidden;
            height: 50px;
            position: fixed;
            bottom: 0;

            width: 100%;
        }
    </style>

<body>
    <!-- header for the page -->
    <h1> Welcome to the guide page</h1>
    <p>Follow the instructions below for more information on how to get started.</p>

    <div class="infographic">

        <img src="images/CleaningPhoto.png" class="photo" alt="cleaningphoto" width="700" height="500">

        <br>
        <!-- instructions on how to use the website -->
        <p>Follow the instructions below for more information on how to get started.</p>
        <p class="bodyText">1. Head over to the services tab via 'Services' at the top of your screen</p>
        <p class="bodyText">2. Browse the service selection for the service you require, use the filers if needed.</p>
        <p class="bodyText">3. Once an ideal service is found, click the service and enter details to make a booking</p>
        <p class="bodyText">4. If you can't find a service you like, try making a custom request and we'll see what our employees can do.</p>
        <p class="bodyText">5. Done!</p>
    </div>


</body>
<!-- footer navbar -->
<div class="topnav" id="bottomnav">
    <p class="footertext" style="color:white">Website created by Sam, Tope, Saahil</p>

</div>
</head>

</html>